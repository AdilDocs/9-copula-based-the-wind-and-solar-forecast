#!/usr/bin/env bash
# Full pipeline. Run from the project root:  bash run_all.sh
# Place the OPSD file time_series_60min_singleindex.csv in data/ first (see README).
set -e
mkdir -p data results figures runs logs

# 0) Data: OPSD -> hourly DE wind/solar capacity factors and load; price proxy
python src/data_prep.py   data/time_series_60min_singleindex.csv
python src/price_model.py data/time_series_60min_singleindex.csv

# 1) Stage 1: dependence models, shortfall probability, synthetic years (Table of dependence models)
python src/run_signals.py
python src/run_scenarios.py 100
python src/pi_highM.py

# 2) Learning-based benchmarks (most time-consuming step)
python src/jobq.py jobs_baselines.txt 2

# 3) Stage 2 + 3: proposed risk-constrained scheduler (scenario table, risk-level selection on 2018, SMCS)
python src/risk_sched.py precompute
python src/risk_sched.py tune
python src/risk_sched.py evaluate

# 4) SMCS of the rule-based and learning-based benchmarks (2019: K=300) and the 2020 stress period (K=800)
python src/evaluate.py 300 200
python src/eval_extra2.py
python src/stress2020_k3000.py

# 5) Alternative Stage-1 uncertainty models inside the same scheduler
python src/alt_stage1.py build
python src/alt_stage1.py tune
python src/alt_stage1.py evaluate
python src/conformal_sched.py fit
python src/conformal_sched.py tune
python src/conformal_sched.py evaluate

# 6) Sensitivity analysis (nine settings, K=64)
python src/sensitivity.py 64
python src/sens_risk.py

# 7) Figures and tables
python src/fig2_data.py
python src/fig2_risk.py
python src/make_report.py
python src/fig3_conv.py
python src/make_tables.py
echo "Done: tables in results/, figures in figures/"
