"""Sensitivity analysis (Fig. 4): frozen policies evaluated on 2019 under modified conditions.
(a) renewable capacity scale, (b) BESS energy/power scale, (c) failure-rate multiplier, (d) load scale.
Usage: python sensitivity.py [K]"""
import glob, sys, pickle, re
import numpy as np
from common import load_data, load_z, year_slice, run_policy
from env import MyopicPolicy, sample_availability
from evaluate import SocRule, load_trained

K = int(sys.argv[1]) if len(sys.argv) > 1 else 64
d, arr = load_data()
zdt = load_z("dt", d)
s, n = year_slice(d, 2019)
pols = {"Myopic OPF": (MyopicPolicy(), None),
        "Rule-based (FCR-first)": (SocRule(lambda e, t: np.full(e.B, 0.55), "fcr"), None),
        "Rule-based (max-reserve)": (SocRule(lambda e, t: np.full(e.B, 1.0), "full"), None)}
for f in sorted(glob.glob("runs/main_z-none_s[0-2].pt")):
    pol, ck = load_trained(f, arr)
    pols[f.split("/")[-1][:-3]] = (pol, None if ck["z"] == "none" else zdt)
grid = {"re": [0.75, 1.0, 1.25], "bess": [0.75, 1.0, 1.25], "fail": [0.5, 1.0, 2.0], "load": [0.95, 1.0, 1.05]}
out = {}
for par, vals in grid.items():
    for v in vals:
        rm = v if par == "fail" else 1.0
        av = sample_availability(K, n, np.random.default_rng(77), rm)
        sc = {"re": v} if par == "re" else {"bess": v} if par == "bess" else {"load": v} if par == "load" else None
        for name, (pol, z) in pols.items():
            r = run_policy(pol, arr, z, s, n, K, np.random.default_rng(0), use_z=z is not None, avail=av, scale=sc)
            out[(par, v, name)] = {k: float(np.mean(r[k])) for k in ["LOLE", "EENS", "FCR", "TC"]}
            print(par, v, name, out[(par, v, name)], flush=True)
pickle.dump(out, open("results/sensitivity.pkl", "wb"))
