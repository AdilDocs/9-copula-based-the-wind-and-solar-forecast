"""Stage 1 -- Dynamic copula modelling of wind-solar dependence and the dependence signal z_t.

Formulation (decision-relevant, H-hour-ahead):
  Y^w_t = Phi^-1( F^w_{m,h}( mean wind CF over t+1..t+H ) )        (normal score of the next-H-hour mean)
  Y^s_t = Phi^-1( F^s_{m,h}( mean solar CF over t+1..t+H ) )
  F_{m,h}: empirical CDF stratified by month (+-1 pooled) and local hour, fitted on the training years.

  Marginal forecasts  : Y^k_t = b_k' phi_t + sigma_k eps^k_t       (phi_t: information available at t)
  Dependence          : (eps^w_t, eps^s_t) ~ C_t  with dynamic copula parameter
        rho_{t+1} = tanh( omega + beta*rho_t + alpha * mean_{j=0..L-1} q(u_{t-H-j}) q(v_{t-H-j}) )
     q = Phi^-1 (Gaussian) or T_nu^-1 (Student-t). Only forecast errors already realised at t
     (issued at t-H or earlier) enter the forcing term, so rho_{t+1} is a genuine real-time forecast.

  Dependence signal   : z_t = [ rho_{t+1} , pi_t ],
        pi_t = P( Y^w_t < y* , Y^s_t < y* | info_t ) = C_{t}( p^w_t , p^s_t ),
        p^k_t = F_eps^k( (y* - b_k' phi_t) / sigma_k ),  y* = Phi^-1(q_d)
     i.e. the probability that the next H hours are a JOINT wind-solar drought (both below their
     q_d-quantile of the month-hour climatology).

Scenario generator (for synthetic-year SMCS):
  Daily-mean normal scores follow AR(1) each, daily innovations are linked by the same copula family
  (fitted on daily data); hourly wind and solar profiles are taken from the training day (same month
  window) whose within-month rank matches the simulated rank (analog-day resampling).
"""
import numpy as np
import pandas as pd
from scipy import stats, optimize
from scipy.special import gammaln
import numba

QGRID = np.linspace(0.0, 1.0, 401)


# ------------------------------------------------------------------------------------------------
class StratECDF:
    """Empirical CDF per (month, hour) stratum with neighbouring months pooled."""

    def __init__(self, values, month, hour):
        self.sorted = {}
        self.qtab = np.zeros((12, 24, len(QGRID)))
        for m in range(12):
            mm = np.isin(month - 1, [(m - 1) % 12, m, (m + 1) % 12])
            for h in range(24):
                v = np.sort(values[mm & (hour == h)])
                self.sorted[(m, h)] = v
                self.qtab[m, h] = np.quantile(v, QGRID)

    def cdf(self, values, month, hour, seed=7):
        rng = np.random.default_rng(seed)
        u = np.empty(len(values))
        for m in range(12):
            for h in range(24):
                sel = (month - 1 == m) & (hour == h)
                if not sel.any():
                    continue
                v = self.sorted[(m, h)]
                lo = np.searchsorted(v, values[sel], "left")
                hi = np.searchsorted(v, values[sel], "right")
                u[sel] = (lo + rng.uniform(size=sel.sum()) * (hi - lo) + 0.5) / (len(v) + 1.0)
        return np.clip(u, 1e-4, 1 - 1e-4)

    def ppf(self, u, month, hour):
        tab = self.qtab[month - 1, hour]
        idx = np.asarray(u) * (len(QGRID) - 1)
        i0 = np.clip(np.floor(idx).astype(int), 0, len(QGRID) - 2)
        w = idx - i0
        a = np.take_along_axis(tab, i0[..., None], -1)[..., 0]
        b = np.take_along_axis(tab, (i0 + 1)[..., None], -1)[..., 0]
        return a + w * (b - a)


# ------------------------------------------------------------------------------------------------
# copula densities and dynamic recursion
# ------------------------------------------------------------------------------------------------
def gauss_logc(x, y, rho):
    r2 = 1 - rho ** 2
    return -0.5 * np.log(r2) - (rho ** 2 * (x ** 2 + y ** 2) - 2 * rho * x * y) / (2 * r2)


def t_logc(x, y, rho, nu):
    r2 = 1 - rho ** 2
    l2 = (gammaln((nu + 2) / 2) - gammaln(nu / 2) - np.log(np.pi * nu) - 0.5 * np.log(r2)
          - (nu + 2) / 2 * np.log1p((x ** 2 - 2 * rho * x * y + y ** 2) / (nu * r2)))

    def l1(z):
        return gammaln((nu + 1) / 2) - gammaln(nu / 2) - 0.5 * np.log(np.pi * nu) - (nu + 1) / 2 * np.log1p(z ** 2 / nu)

    return l2 - l1(x) - l1(y)


def forcing(p, L, off):
    """m[t] = mean(p[t-off-L+1 .. t-off]) (0 if empty) -- information available after time t."""
    c = np.concatenate([[0.0], np.cumsum(p)])
    t = np.arange(len(p))
    hi = np.clip(t - off + 1, 0, len(p))
    lo = np.clip(hi - L, 0, None)
    return np.where(hi > lo, (c[hi] - c[lo]) / np.maximum(hi - lo, 1), 0.0)


@numba.njit(cache=True)
def _rho_path(om, be, al, m, rho0):
    n = m.shape[0]
    rho = np.empty(n + 1)
    rho[0] = rho0
    for t in range(n):
        r = np.tanh(om + be * rho[t] + al * m[t])
        rho[t + 1] = min(max(r, -0.995), 0.995)
    return rho  # rho[t]: parameter for obs t ; rho[n]: one-step-ahead


KINDS = ["indep", "gauss", "t", "dgauss", "dt"]
NAMES = {"indep": "Independent", "gauss": "Static Gaussian", "t": "Static t",
         "dgauss": "Dynamic Gaussian", "dt": "Dynamic t"}


class Copula:
    def __init__(self, kind, L=24, off=0):
        self.kind, self.L, self.off = kind, L, off
        self.params = np.array([])
        self.rho0 = 0.0

    @property
    def npar(self):
        return {"indep": 0, "gauss": 1, "t": 2, "dgauss": 3, "dt": 4}[self.kind]

    @property
    def nu(self):
        if self.kind == "t":
            return 2 + np.exp(self.params[1])
        if self.kind == "dt":
            return 2 + np.exp(self.params[3])
        return None

    def _eval(self, th, u, v):
        k = self.kind
        if k == "indep":
            return np.zeros(len(u)), np.zeros(len(u) + 1)
        nu = None
        if k == "t":
            nu = 2 + np.exp(th[1])
        if k == "dt":
            nu = 2 + np.exp(th[3])
        if nu is None:
            x, y = stats.norm.ppf(u), stats.norm.ppf(v)
        else:
            x, y = stats.t.ppf(u, nu), stats.t.ppf(v, nu)
        if k in ("gauss", "t"):
            path = np.full(len(u) + 1, np.tanh(th[0]))
        else:
            path = _rho_path(th[0], th[1], th[2], forcing(x * y, self.L, self.off), self.rho0)
        rho = path[:-1]
        ll = gauss_logc(x, y, rho) if nu is None else t_logc(x, y, rho, nu)
        return ll, path

    def nll(self, th, u, v):
        s = -np.sum(self._eval(th, u, v)[0])
        return s if np.isfinite(s) else 1e12

    def fit(self, u, v):
        self.rho0 = float(np.corrcoef(stats.norm.ppf(u), stats.norm.ppf(v))[0, 1])
        k = self.kind
        if k == "indep":
            self.ll = 0.0
            return self
        r0 = np.arctanh(self.rho0)
        if k == "gauss":
            starts = [np.array([r0])]
        elif k == "t":
            starts = [np.array([r0, np.log(n - 2)]) for n in (4, 10, 30)]
        elif k == "dgauss":
            starts = [np.array([r0 * (1 - b), b, a]) for b in (0.3, 0.8, 0.95) for a in (0.05, 0.3)]
        else:
            starts = [np.array([r0 * (1 - b), b, a, np.log(n - 2)]) for b in (0.3, 0.8, 0.95)
                      for a in (0.05, 0.3) for n in (6, 20)]
        best = None
        for th0 in starts:
            r = optimize.minimize(self.nll, th0, args=(u, v), method="Nelder-Mead",
                                  options={"maxiter": 3000, "xatol": 1e-5, "fatol": 1e-3})
            if best is None or r.fun < best.fun:
                best = r
        self.params = best.x
        self.ll = -best.fun
        return self

    def loglik(self, u, v):
        return float(np.sum(self._eval(self.params, u, v)[0]))

    def path(self, u, v):
        return self._eval(self.params, u, v)[1]

    def describe(self):
        p, k = self.params, self.kind
        if k == "indep":
            return {}
        if k == "gauss":
            return {"rho": np.tanh(p[0])}
        if k == "t":
            return {"rho": np.tanh(p[0]), "nu": self.nu}
        d = {"omega": p[0], "beta": p[1], "alpha": p[2]}
        if k == "dt":
            d["nu"] = self.nu
        return d

    # ---- sampling / CDF via common random numbers ----
    def draws(self, rho, rng):
        """rho: array (n,) -> (u, v) arrays (n,)"""
        n = len(rho)
        z1 = rng.standard_normal(n)
        if self.kind == "indep":
            return stats.norm.cdf(z1), rng.uniform(size=n)
        z2 = rho * z1 + np.sqrt(1 - rho ** 2) * rng.standard_normal(n)
        nu = self.nu
        if nu is None:
            return stats.norm.cdf(z1), stats.norm.cdf(z2)
        w = np.sqrt(nu / rng.chisquare(nu, n))
        return stats.t.cdf(z1 * w, nu), stats.t.cdf(z2 * w, nu)

    def cdf(self, a, b, rho, M=4000, seed=11, chunk=500):
        """C_rho(a, b) for arrays a, b, rho (same length) by Monte-Carlo with common random numbers."""
        if self.kind == "indep":
            return a * b
        rng = np.random.default_rng(seed)
        z1 = rng.standard_normal(M)
        z3 = rng.standard_normal(M)
        nu = self.nu
        w = np.ones(M) if nu is None else np.sqrt(nu / rng.chisquare(nu, M))
        if nu is None:
            qa, qb = stats.norm.ppf(a), stats.norm.ppf(b)
        else:
            qa, qb = stats.t.ppf(a, nu), stats.t.ppf(b, nu)
        out = np.empty(len(a))
        for c0 in range(0, len(a), chunk):
            sl = slice(c0, c0 + chunk)
            r = rho[sl, None]
            x = z1[None] * w[None]
            y = (r * z1[None] + np.sqrt(1 - r ** 2) * z3[None]) * w[None]
            out[sl] = np.mean((x < qa[sl, None]) & (y < qb[sl, None]), 1)
        return out

    def lower_tail(self, rho, q, n=400000, seed=3):
        rng = np.random.default_rng(seed)
        rr = rng.choice(np.atleast_1d(rho), n)
        u, v = self.draws(rr, rng)
        return np.mean((u < q) & (v < q)) / q


# ------------------------------------------------------------------------------------------------
# Joint forecasting model (marginal forecasts + copula)  -> dependence signal
# ------------------------------------------------------------------------------------------------
class JointDroughtModel:
    def __init__(self, H=24, qd=0.1, L=48):
        self.H, self.qd, self.L = H, qd, L

    @staticmethod
    def targets(d, H):
        Wf = d["wind"].rolling(H).mean().shift(-H).values
        Sf = d["solar"].rolling(H).mean().shift(-H).values
        return Wf, Sf

    def _scores(self, d):
        m, h = d["month"].values, d["hour"].values
        xw = stats.norm.ppf(self.cw.cdf(d["wind"].values, m, h))
        pw = d["wind"].rolling(self.H, min_periods=1).mean().values
        ps = d["solar"].rolling(self.H, min_periods=1).mean().values
        xpw = stats.norm.ppf(self.cW.cdf(pw, m, h))
        xps = stats.norm.ppf(self.cS.cdf(ps, m, h))
        xw6 = pd.Series(xw).shift(6).bfill().values
        phi = np.column_stack([np.ones(len(d)), xw, xw6, xpw, xps])
        Wf, Sf = self.targets(d, self.H)
        ok = ~np.isnan(Wf)
        yw = np.full(len(d), np.nan)
        ys = np.full(len(d), np.nan)
        yw[ok] = stats.norm.ppf(self.cW.cdf(Wf[ok], m[ok], h[ok]))
        ys[ok] = stats.norm.ppf(self.cS.cdf(Sf[ok], m[ok], h[ok]))
        return phi, yw, ys

    def fit_marginals(self, d_train):
        m, h = d_train["month"].values, d_train["hour"].values
        Wf, Sf = self.targets(d_train, self.H)
        ok = ~np.isnan(Wf)
        self.cw = StratECDF(d_train["wind"].values, m, h)
        self.cW = StratECDF(Wf[ok], m[ok], h[ok])
        self.cS = StratECDF(Sf[ok], m[ok], h[ok])
        phi, yw, ys = self._scores(d_train)
        ok = ~np.isnan(yw)
        self.bw = np.linalg.lstsq(phi[ok], yw[ok], rcond=None)[0]
        self.bs = np.linalg.lstsq(phi[ok], ys[ok], rcond=None)[0]
        ew = (yw[ok] - phi[ok] @ self.bw)
        es = (ys[ok] - phi[ok] @ self.bs)
        self.sw, self.ss = ew.std(), es.std()
        self.ew_sorted = np.sort(ew / self.sw)
        self.es_sorted = np.sort(es / self.ss)
        self.r2 = (1 - ew.var() / yw[ok].var(), 1 - es.var() / ys[ok].var())
        return self

    def _ecdf(self, s, x):
        return np.clip((np.searchsorted(s, x) + 0.5) / (len(s) + 1), 1e-4, 1 - 1e-4)

    def residual_pobs(self, d):
        phi, yw, ys = self._scores(d)
        u = self._ecdf(self.ew_sorted, (yw - phi @ self.bw) / self.sw)
        v = self._ecdf(self.es_sorted, (ys - phi @ self.bs) / self.ss)
        ok = ~np.isnan(yw)
        return phi, u, v, ok, yw, ys

    def fit_copula(self, d_train, kind):
        _, u, v, ok, _, _ = self.residual_pobs(d_train)
        self.cop = Copula(kind, L=self.L, off=self.H).fit(u[ok], v[ok])
        return self

    def signal(self, d):
        """z_t = [rho_{t+1}, pi_t] plus diagnostics (marginal drought probs, realised joint drought)."""
        phi, u, v, ok, yw, ys = self.residual_pobs(d)
        ystar = stats.norm.ppf(self.qd)
        pw = self._ecdf(self.ew_sorted, (ystar - phi @ self.bw) / self.sw)
        ps = self._ecdf(self.es_sorted, (ystar - phi @ self.bs) / self.ss)
        n = len(d)
        # forecast errors realised only H hours later: unrealised entries are masked by off=H
        uu = np.where(ok, u, 0.5)
        vv = np.where(ok, v, 0.5)
        path = self.cop._eval(self.cop.params, uu, vv)[1] if self.cop.kind != "indep" else np.zeros(n + 1)
        rho_t = path[:-1]  # parameter that applies to forecast issued at t (uses info <= t-H)
        pi = self.cop.cdf(pw, ps, rho_t)
        joint = np.where(ok, (yw < ystar) & (ys < ystar), np.nan)
        return pd.DataFrame({"rho": rho_t, "pi": pi, "pw": pw, "ps": ps, "joint": joint}, index=d.index)


def combined_shortage(model, d, wW, wS, q=0.2, M=500, seed=5, chunk=400, d_train=None):
    """pi_t = P( wW*Wbar + wS*Sbar < thr_{m,h} | info_t ) with (Wbar,Sbar) the next-H-hour mean CFs,
    joint predictive distribution = marginal forecasts + fitted copula (parameter rho_t).
    thr_{m,h}: q-quantile of the combined next-H-hour energy in the training data (month+-1, hour)."""
    H = model.H
    if not hasattr(model, "cC"):
        Wf, Sf = model.targets(d_train, H)
        ok = ~np.isnan(Wf)
        comb = wW * Wf[ok] + wS * Sf[ok]
        cC = StratECDF(comb, d_train["month"].values[ok], d_train["hour"].values[ok])
        model.thr = cC.qtab[:, :, int(round(q * (len(QGRID) - 1)))]
        model.cC = cC
    phi, u, v, ok, yw, ys = model.residual_pobs(d)
    mu_w, mu_s = phi @ model.bw, phi @ model.bs
    uu, vv = np.where(ok, u, 0.5), np.where(ok, v, 0.5)
    cop = model.cop
    rho = cop._eval(cop.params, uu, vv)[1][:-1] if cop.kind != "indep" else np.zeros(len(d))
    rng = np.random.default_rng(seed)
    z1, z3 = rng.standard_normal(M), rng.standard_normal(M)
    nu = cop.nu
    w = np.ones(M) if nu is None else np.sqrt(nu / rng.chisquare(nu, M))
    z3i = rng.standard_normal(M)
    mon, hr = d["month"].values, d["hour"].values
    pi = np.empty(len(d))
    for c0 in range(0, len(d), chunk):
        sl = slice(c0, c0 + chunk)
        r = rho[sl, None]
        if cop.kind == "indep":
            a1, a2 = stats.norm.cdf(z1)[None].repeat(len(r), 0), stats.norm.cdf(z3i)[None].repeat(len(r), 0)
        elif nu is None:
            a1 = stats.norm.cdf(z1)[None].repeat(len(r), 0)
            a2 = stats.norm.cdf(r * z1[None] + np.sqrt(1 - r ** 2) * z3[None])
        else:
            a1 = stats.t.cdf((z1 * w)[None], nu).repeat(len(r), 0)
            a2 = stats.t.cdf((r * z1[None] + np.sqrt(1 - r ** 2) * z3[None]) * w[None], nu)
        ew = np.interp(a1, (np.arange(len(model.ew_sorted)) + .5) / (len(model.ew_sorted) + 1), model.ew_sorted)
        es = np.interp(a2, (np.arange(len(model.es_sorted)) + .5) / (len(model.es_sorted) + 1), model.es_sorted)
        Yw = mu_w[sl, None] + model.sw * ew
        Ys = mu_s[sl, None] + model.ss * es
        mm, hh = mon[sl, None].repeat(M, 1), hr[sl, None].repeat(M, 1)
        Wb = model.cW.ppf(stats.norm.cdf(Yw), mm, hh)
        Sb = model.cS.ppf(stats.norm.cdf(Ys), mm, hh)
        pi[sl] = np.mean(wW * Wb + wS * Sb < model.thr[mon[sl] - 1, hr[sl]][:, None], 1)
    Wf, Sf = model.targets(d, H)
    real = np.where(np.isnan(Wf), np.nan, (wW * Wf + wS * Sf) < model.thr[mon - 1, hr])
    return pd.DataFrame({"rho": rho, "pi": pi, "real": real}, index=d.index)


# ------------------------------------------------------------------------------------------------
# Analog-day scenario generator (daily copula)
# ------------------------------------------------------------------------------------------------
class AnalogDayGenerator:
    def __init__(self, d_train, kind, L=7):
        self.kind = kind
        day = d_train.index.tz_convert("Europe/Berlin").normalize()
        g = d_train.groupby(day)
        cnt = g.size()
        full = cnt[cnt == 24].index
        self.days = full
        self.W = np.stack([g.get_group(k)["wind"].values for k in full])
        self.S = np.stack([g.get_group(k)["solar"].values for k in full])
        self.doy = np.array([k.dayofyear for k in full])
        self.month = np.array([k.month for k in full])
        dw, ds = self.W.mean(1), self.S.mean(1)
        # within-month ranks -> normal scores
        grp = pd.Series(dw).groupby(self.month)
        nmon = grp.transform("size").values
        self.rw = pd.Series(dw).groupby(self.month).rank().values / (nmon + 1)
        self.rs = pd.Series(ds).groupby(self.month).rank().values / (nmon + 1)
        xw, xs = stats.norm.ppf(self.rw), stats.norm.ppf(self.rs)
        # AR(1) on consecutive days
        cons = (np.diff(full.values).astype("timedelta64[h]").astype(int) == 24)
        self.aw = np.sum(xw[1:][cons] * xw[:-1][cons]) / np.sum(xw[:-1][cons] ** 2)
        self.as_ = np.sum(xs[1:][cons] * xs[:-1][cons]) / np.sum(xs[:-1][cons] ** 2)
        cons = np.r_[False, cons]
        ew = (xw[1:] - self.aw * xw[:-1])[cons[1:]]
        es = (xs[1:] - self.as_ * xs[:-1])[cons[1:]]
        self.sw, self.ss = ew.std(), es.std()
        u = stats.rankdata(ew) / (len(ew) + 1)
        v = stats.rankdata(es) / (len(es) + 1)
        self.cop = Copula(kind, L=L, off=0).fit(u, v)
        self.ew_sorted, self.es_sorted = np.sort(ew / self.sw), np.sort(es / self.ss)

    def _inv(self, s, u):
        return np.interp(u, (np.arange(len(s)) + 0.5) / (len(s) + 1), s)

    def generate(self, calendar_days, n_years, rng):
        """calendar_days: DatetimeIndex of local days to fill. Returns W, S arrays (n_years, n_days*24)."""
        nd = len(calendar_days)
        doy = np.array([k.dayofyear for k in calendar_days])
        W = np.empty((n_years, nd, 24))
        S = np.empty((n_years, nd, 24))
        xw = np.zeros(n_years)
        xs = np.zeros(n_years)
        k = self.cop.kind
        if k in ("dgauss", "dt"):
            rho = np.full(n_years, self.cop.rho0)
        elif k in ("gauss", "t"):
            rho = np.full(n_years, np.tanh(self.cop.params[0]))
        else:
            rho = np.zeros(n_years)
        nu = self.cop.nu
        q = (lambda x: stats.norm.ppf(x)) if nu is None else (lambda x: stats.t.ppf(x, nu))
        hist = np.zeros((n_years, self.cop.L))
        # candidate pools by day-of-year window (+-15 d)
        for j in range(nd):
            u1, u2 = self.cop.draws(rho, rng)
            xw = self.aw * xw + self.sw * self._inv(self.ew_sorted, u1)
            xs = self.as_ * xs + self.ss * self._inv(self.es_sorted, u2)
            if k in ("dgauss", "dt"):
                hist[:, j % self.cop.L] = q(u1) * q(u2)
                mb = hist[:, :min(j + 1, self.cop.L)].mean(1)
                om, be, al = self.cop.params[:3]
                rho = np.clip(np.tanh(om + be * rho + al * mb), -0.995, 0.995)
            dd = np.abs(((self.doy - doy[j]) + 183) % 366 - 183)
            pool = np.where(dd <= 15)[0]
            tw, ts = stats.norm.cdf(xw), stats.norm.cdf(xs)
            # choose analog day by nearest rank within the pool (rank among pool by daily mean)
            pw = self.W[pool].mean(1)
            ps = self.S[pool].mean(1)
            ow, os_ = np.argsort(pw), np.argsort(ps)
            iw = pool[ow[np.clip((tw * len(pool)).astype(int), 0, len(pool) - 1)]]
            is_ = pool[os_[np.clip((ts * len(pool)).astype(int), 0, len(pool) - 1)]]
            W[:, j] = self.W[iw]
            S[:, j] = self.S[is_]
        return W.reshape(n_years, -1), S.reshape(n_years, -1)
