"""Constrained RL baseline in the spirit of Wu, Scaglione & Arnold (2024): a single centralised PPO agent
minimises operating cost subject to a constraint on expected unserved energy, enforced with a Lagrange
multiplier (PPO-Lagrangian). Same environment, SOC set-point actions, safety layer and validation protocol.
Usage: python ppo_lag.py --seed 0"""
import argparse, json, os, time
import numpy as np
import torch
import torch.nn as nn
from common import load_data, year_slice, run_policy
from env import FeederEnv, Z, sample_availability
from mappo import mlp

torch.set_num_threads(1)


class LagAgent(nn.Module):
    def __init__(self, D):
        super().__init__()
        self.pi = mlp(D * Z, Z, 256)
        self.logstd = nn.Parameter(torch.full((Z,), -1.2))
        with torch.no_grad():
            self.pi[-1].weight.mul_(0.1); self.pi[-1].bias.fill_(0.3)
        self.vr = mlp(D * Z, 1, 256)
        self.vc = mlp(D * Z, 1, 256)

    def dist(self, o):
        mu = self.pi(o.reshape(o.shape[0], -1))
        return torch.distributions.Normal(mu, self.logstd.exp().expand_as(mu))

    def values(self, o):
        x = o.reshape(o.shape[0], -1)
        return self.vr(x).squeeze(-1), self.vc(x).squeeze(-1)


class LagPolicy:
    def __init__(self, ag):
        self.ag = ag

    def act(self, env):
        o = torch.as_tensor(env._obs(), dtype=torch.float32)
        with torch.no_grad():
            mu = self.ag.dist(o).mean.numpy()
        return env.soc_target_to_power(np.clip(mu, -1, 1))


def gae(R, V, vlast, gamma, lam):
    T = len(R)
    adv = torch.zeros(T, R[0].shape[0])
    g = torch.zeros(R[0].shape[0])
    for t in reversed(range(T)):
        vn = vlast if t == T - 1 else V[t + 1]
        g = R[t] + gamma * vn - V[t] + gamma * lam * g
        adv[t] = g
    return adv, adv + torch.stack(V)


def train(args):
    rng = np.random.default_rng(args.seed)
    torch.manual_seed(args.seed)
    d, arr = load_data()
    s_tr, n_tr = year_slice(d, 2015, 2017)
    s_va, n_va = year_slice(d, 2018)
    tr_arr = {k: v[s_tr:s_tr + n_tr] for k, v in arr.items()}
    env = FeederEnv(tr_arr, None, B=args.B, ep_len=168, rng=rng, rate_mult=0.0, use_z=False)
    env.soc_mode = True
    D = env.obs_dim
    ag = LagAgent(D)
    opt_pi = torch.optim.Adam(list(ag.pi.parameters()) + [ag.logstd], lr=args.lr)
    opt_v = torch.optim.Adam(list(ag.vr.parameters()) + list(ag.vc.parameters()), lr=1e-3)
    lam_mult = 1.0
    limit = args.eens_limit / 8760.0           # MWh per hour (expected unserved power)
    vav = sample_availability(args.Kval, n_va, np.random.default_rng(1234), 1.0)
    best, log, t0 = (np.inf, None), [], time.time()
    for upd in range(args.updates):
        o = env.reset()
        O, A, LP, R, C, VR, VC = [], [], [], [], [], [], []
        done = False
        while not done:
            ot = torch.as_tensor(o, dtype=torch.float32)
            with torch.no_grad():
                dist = ag.dist(ot)
                a = dist.sample()
                vr, vc = ag.values(ot)
            o, r, done, info = env.step(a.numpy())
            r_rel = -10.0 * info["ens"]
            O.append(ot); A.append(a); LP.append(dist.log_prob(a).sum(-1))
            R.append(torch.as_tensor((r - r_rel) * args.rscale, dtype=torch.float32))
            C.append(torch.as_tensor(info["ens"], dtype=torch.float32)); VR.append(vr); VC.append(vc)
        with torch.no_grad():
            vrl, vcl = ag.values(torch.as_tensor(o, dtype=torch.float32))
        ar, retr = gae(R, VR, vrl, args.gamma, args.lam)
        ac, retc = gae(C, VC, vcl, args.gamma, args.lam)
        # Lagrange multiplier update (dual ascent on the average unserved power)
        jc = float(torch.stack(C).mean())
        lam_mult = max(0.0, lam_mult + args.lr_lam * (jc - limit) / max(limit, 1e-6))
        adv = (ar - lam_mult * ac) / (1 + lam_mult)
        T = len(R)
        O = torch.stack(O).reshape(T * args.B, Z, D); A = torch.stack(A).reshape(T * args.B, Z)
        LP = torch.stack(LP).reshape(-1); adv = adv.reshape(-1)
        retr, retc = retr.reshape(-1), retc.reshape(-1)
        adv = (adv - adv.mean()) / (adv.std() + 1e-8)
        N = O.shape[0]
        for _ in range(args.epochs):
            perm = torch.randperm(N)
            for i in range(0, N, args.mb):
                b = perm[i:i + args.mb]
                dist = ag.dist(O[b])
                ratio = (dist.log_prob(A[b]).sum(-1) - LP[b]).exp()
                lp = -torch.min(ratio * adv[b], ratio.clamp(1 - args.clip, 1 + args.clip) * adv[b]).mean()
                opt_pi.zero_grad(); lp.backward()
                nn.utils.clip_grad_norm_(list(ag.pi.parameters()) + [ag.logstd], 0.5); opt_pi.step()
                vr, vc = ag.values(O[b])
                lv = ((vr - retr[b]) ** 2).mean() + ((vc - retc[b]) ** 2).mean()
                opt_v.zero_grad(); lv.backward(); opt_v.step()
        if (upd + 1) % args.eval_every == 0:
            res = run_policy(LagPolicy(ag), arr, None, s_va, n_va, args.Kval, np.random.default_rng(0), use_z=False, avail=vav)
            rec = {"update": upd, "steps": (upd + 1) * T * args.B, "lambda": lam_mult, "time": time.time() - t0}
            rec.update({k: float(np.mean(v)) for k, v in res.items() if k not in ("ens_t", "lol_t")})
            if rec["TC"] < best[0]:
                best = (rec["TC"], {k: v.clone() for k, v in ag.state_dict().items()})
            log.append(rec)
            print(json.dumps({k: round(v, 3) if isinstance(v, float) else v for k, v in rec.items()}), flush=True)
    os.makedirs("runs", exist_ok=True)
    name = f"runs/comp_ppolag_s{args.seed}"
    torch.save({"state": best[1], "D": D, "best_val_TC": best[0]}, name + ".pt")
    json.dump(log, open(name + "_log.json", "w"))
    return name


if __name__ == "__main__":
    p = argparse.ArgumentParser()
    p.add_argument("--seed", type=int, default=0)
    p.add_argument("--updates", type=int, default=250)
    p.add_argument("--B", type=int, default=128)
    p.add_argument("--lr", type=float, default=5e-4)
    p.add_argument("--gamma", type=float, default=0.995)
    p.add_argument("--lam", type=float, default=0.95)
    p.add_argument("--clip", type=float, default=0.2)
    p.add_argument("--epochs", type=int, default=5)
    p.add_argument("--mb", type=int, default=2048)
    p.add_argument("--rscale", type=float, default=1.0)
    p.add_argument("--lr_lam", type=float, default=0.05)
    p.add_argument("--eens_limit", type=float, default=50.0, help="EENS limit [MWh/yr]")
    p.add_argument("--Kval", type=int, default=32)
    p.add_argument("--eval_every", type=int, default=25)
    print(train(p.parse_args()))
