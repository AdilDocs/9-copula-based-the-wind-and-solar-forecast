"""Trajectories for Fig. 2: deterministic 2019 replay (no failures) of proposed / no-z / FCR rule."""
import pickle
import numpy as np
from common import load_data, load_z, year_slice, run_policy
from env import sample_availability
from evaluate import SocRule, load_trained

d, arr = load_data()
s, n = year_slice(d, 2019)
zdt = load_z("dt", d)
zin = load_z("indep", d)
av = sample_availability(1, n, np.random.default_rng(0), 0.0)
pz, _ = load_trained("runs/main_z-dt_s0.pt", arr)
pn, _ = load_trained("runs/main_z-none_s0.pt", arr)
fcr = SocRule(lambda e, t: np.full(e.B, 0.55), "fcr")
soc = {}
for nm, p, z in (("z", pz, zdt), ("noz", pn, None), ("fcr", fcr, None)):
    r = run_policy(p, arr, z, s, n, 1, np.random.default_rng(0), use_z=z is not None, avail=av, record=True)
    soc[nm] = np.array([x["soc"].mean() for x in r["rec"]])
    print(nm, "EENS no-failure", r["EENS"])
# window: 12 days centred on the hour with the highest 24-h rolling pi in Jan-Mar / Oct-Dec 2019
pi = zdt[s:s + n, 1] * 0.2 + 0.2
roll = np.convolve(pi, np.ones(72) / 72, "same")
mon = arr["month"][s:s + n]
roll[~np.isin(mon, [1, 2, 3, 10, 11, 12])] = 0
c = int(np.argmax(roll))
a, b = max(c - 144, 0), min(c + 144, n)
idx = d.index[s:s + n]
out = dict(start=idx[a], end=idx[b - 1], soc_z=soc["z"][a:b], soc_noz=soc["noz"][a:b], soc_fcr=soc["fcr"][a:b],
           pi_indep=zin[s + a:s + b, 1] * 0.2 + 0.2)
pickle.dump(out, open("results/fig2_traj.pkl", "wb"))
print(out["start"], out["end"])
