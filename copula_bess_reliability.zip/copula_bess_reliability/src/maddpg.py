"""MADDPG baseline (Lowe et al., 2017): shared deterministic actor (local obs + agent id),
centralised critic Q(s, a_1..a_N), replay buffer, target networks, Gaussian exploration.
Same environment, SOC set-point actions, safety layer and validation protocol as mappo.py.
Usage: python maddpg.py --seed 0 --steps 6000"""
import argparse, json, os, time
import numpy as np
import torch
import torch.nn as nn
from common import load_data, year_slice, run_policy
from env import FeederEnv, Z, sample_availability

torch.set_num_threads(1)


def mlp(i, o, h, out_act=None):
    layers = [nn.Linear(i, h), nn.ReLU(), nn.Linear(h, h), nn.ReLU(), nn.Linear(h, o)]
    if out_act:
        layers.append(out_act)
    return nn.Sequential(*layers)


class DetPolicy:
    def __init__(self, actor):
        self.actor = actor
        self.eye = torch.eye(Z)

    def mu(self, o):
        ids = self.eye.expand(o.shape[0], Z, Z)
        return self.actor(torch.cat([o, ids], -1)).squeeze(-1)

    def act(self, env):
        o = torch.as_tensor(env._obs(), dtype=torch.float32)
        with torch.no_grad():
            a = self.mu(o).numpy()
        return env.soc_target_to_power(a)


def train(args):
    rng = np.random.default_rng(args.seed)
    torch.manual_seed(args.seed)
    d, arr = load_data()
    s_tr, n_tr = year_slice(d, 2015, 2017)
    s_va, n_va = year_slice(d, 2018)
    tr_arr = {k: v[s_tr:s_tr + n_tr] for k, v in arr.items()}
    env = FeederEnv(tr_arr, None, B=args.B, ep_len=168, rng=rng, rate_mult=0.0, use_z=False)
    env.soc_mode = True
    D = env.obs_dim
    actor = mlp(D + Z, 1, 128, nn.Tanh())
    critic = mlp(D * Z + Z, 1, 256)
    critic2 = mlp(D * Z + Z, 1, 256)       # second critic (security / unserved energy), two-critic variant
    critic2_t = mlp(D * Z + Z, 1, 256); critic2_t.load_state_dict(critic2.state_dict())
    oc2 = torch.optim.Adam(critic2.parameters(), lr=args.lr_c)
    actor_t = mlp(D + Z, 1, 128, nn.Tanh()); actor_t.load_state_dict(actor.state_dict())
    critic_t = mlp(D * Z + Z, 1, 256); critic_t.load_state_dict(critic.state_dict())
    with torch.no_grad():   # start near SOC set-point ~0.7, as for MAPPO
        actor[-2].weight.mul_(0.1); actor[-2].bias.fill_(0.3)
        actor_t.load_state_dict(actor.state_dict())
    oa = torch.optim.Adam(actor.parameters(), lr=args.lr_a)
    oc = torch.optim.Adam(critic.parameters(), lr=args.lr_c)
    pol, pol_t = DetPolicy(actor), DetPolicy(actor_t)
    cap = args.buffer
    bo = np.zeros((cap, Z, D), np.float32); ba = np.zeros((cap, Z), np.float32)
    br2 = np.zeros(cap, np.float32)
    br = np.zeros(cap, np.float32); bo2 = np.zeros((cap, Z, D), np.float32); bd = np.zeros(cap, np.float32)
    ptr, full = 0, False
    vav = sample_availability(args.Kval, n_va, np.random.default_rng(1234), 1.0)
    best, log, t0 = (np.inf, None), [], time.time()
    o = env.reset()
    for step in range(args.steps):
        ot = torch.as_tensor(o, dtype=torch.float32)
        with torch.no_grad():
            a = pol.mu(ot).numpy()
        a = np.clip(a + args.noise * rng.standard_normal(a.shape), -1, 1)
        o2, r, done, info = env.step(a)
        r_rel = -10.0 * info["ens"]          # VOLL part of the reward (10000 EUR/MWh / 1000)
        if args.twocritic:
            r, r2 = r - r_rel, r_rel
        else:
            r2 = np.zeros_like(r)
        n = args.B
        idx = (np.arange(n) + ptr) % cap
        bo[idx], ba[idx], br[idx], bo2[idx], bd[idx] = o, a, r, o2, float(done)
        br2[idx] = r2
        ptr = (ptr + n) % cap
        full = full or ptr < n
        o = env.reset() if done else o2
        size = cap if full else ptr
        if size >= args.batch and step >= args.warmup:
            j = rng.integers(0, size, args.batch)
            O, A = torch.as_tensor(bo[j]), torch.as_tensor(ba[j])
            Rw, O2, Dn = torch.as_tensor(br[j]), torch.as_tensor(bo2[j]), torch.as_tensor(bd[j])
            with torch.no_grad():
                a2 = pol_t.mu(O2)
                # episodes are truncated windows of continuous operation -> bootstrap through the boundary
                y = Rw + args.gamma * critic_t(torch.cat([O2.reshape(len(j), -1), a2], -1)).squeeze(-1)
            q = critic(torch.cat([O.reshape(len(j), -1), A], -1)).squeeze(-1)
            lc = ((q - y) ** 2).mean()
            oc.zero_grad(); lc.backward(); nn.utils.clip_grad_norm_(critic.parameters(), 1.0); oc.step()
            sa = torch.cat([O.reshape(len(j), -1), pol.mu(O)], -1)
            if args.twocritic:
                R2 = torch.as_tensor(br2[j])
                with torch.no_grad():
                    y2 = R2 + args.gamma * critic2_t(torch.cat([O2.reshape(len(j), -1), a2], -1)).squeeze(-1)
                q2 = critic2(torch.cat([O.reshape(len(j), -1), A], -1)).squeeze(-1)
                l2 = ((q2 - y2) ** 2).mean()
                oc2.zero_grad(); l2.backward(); nn.utils.clip_grad_norm_(critic2.parameters(), 1.0); oc2.step()
                la = -(critic(sa) + critic2(sa)).mean()
            else:
                la = -critic(sa).mean()
            oa.zero_grad(); la.backward(); nn.utils.clip_grad_norm_(actor.parameters(), 1.0); oa.step()
            with torch.no_grad():
                for p, pt in zip(list(actor.parameters()) + list(critic.parameters()) + list(critic2.parameters()),
                                 list(actor_t.parameters()) + list(critic_t.parameters()) + list(critic2_t.parameters())):
                    pt.mul_(1 - args.tau).add_(args.tau * p)
        if (step + 1) % args.eval_every == 0:
            res = run_policy(pol, arr, None, s_va, n_va, args.Kval, np.random.default_rng(0), use_z=False, avail=vav)
            rec = {"step": step + 1, "transitions": (step + 1) * args.B, "time": time.time() - t0}
            rec.update({k: float(np.mean(v)) for k, v in res.items() if k not in ("ens_t", "lol_t")})
            if rec["TC"] < best[0]:
                best = (rec["TC"], {k: v.clone() for k, v in actor.state_dict().items()})
            log.append(rec)
            print(json.dumps({k: round(v, 3) for k, v in rec.items()}), flush=True)
    os.makedirs("runs", exist_ok=True)
    name = f"runs/comp_maddpg{'2c' if args.twocritic else ''}_s{args.seed}"
    torch.save({"actor": best[1], "D": D, "best_val_TC": best[0]}, name + ".pt")
    json.dump(log, open(name + "_log.json", "w"))
    return name


if __name__ == "__main__":
    p = argparse.ArgumentParser()
    p.add_argument("--seed", type=int, default=0)
    p.add_argument("--steps", type=int, default=6000)
    p.add_argument("--B", type=int, default=32)
    p.add_argument("--batch", type=int, default=1024)
    p.add_argument("--buffer", type=int, default=200000)
    p.add_argument("--warmup", type=int, default=200)
    p.add_argument("--gamma", type=float, default=0.99)
    p.add_argument("--tau", type=float, default=0.005)
    p.add_argument("--lr_a", type=float, default=1e-4)
    p.add_argument("--lr_c", type=float, default=1e-3)
    p.add_argument("--noise", type=float, default=0.2)
    p.add_argument("--Kval", type=int, default=32)
    p.add_argument("--eval_every", type=int, default=500)
    p.add_argument("--twocritic", action="store_true")
    print(train(p.parse_args()))
