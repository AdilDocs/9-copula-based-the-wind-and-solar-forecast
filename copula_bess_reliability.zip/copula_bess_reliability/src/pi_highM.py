"""Shortfall probability pi_t with M_pi = 8000 draws for 2018-2019 (Table 3 statistics and Fig. 2)."""
import pickle, numpy as np, pandas as pd
from stage1 import *
from config import FEEDER, SIG
d = pd.read_pickle("data/de_hourly.pkl"); tr = d[d.year <= 2017]
wW, wS = sum(FEEDER["wind"]), sum(FEEDER["pv"]); wW, wS = wW / (wW + wS), wS / (wW + wS)
base = JointDroughtModel(H=24, qd=SIG["q"], L=SIG["L"]).fit_marginals(tr)
dte = d[(d.year >= 2018) & (d.year <= 2019)]
real_tr = combined_shortage  # placeholder to keep imports explicit
rows, sigs = [], {}
for k in KINDS:
    m = JointDroughtModel(H=24, qd=SIG["q"], L=SIG["L"]); m.__dict__.update(base.__dict__); m.fit_copula(tr, k)
    z = combined_shortage(m, dte, wW, wS, q=SIG["q_short"], d_train=tr, M=8000, seed=5, chunk=100)
    sigs[k] = z
    zt = z.dropna()
    # climatological reference frequency from the fitting period (as in run_signals.py)
    Wf, Sf = m.targets(tr, 24); ok = ~np.isnan(Wf)
    clim = np.mean((wW * Wf[ok] + wS * Sf[ok]) < m.thr[tr.month.values[ok] - 1, tr.hour.values[ok]])
    br = np.mean((zt.pi - zt.real) ** 2); bss = 1 - br / np.mean((clim - zt.real) ** 2)
    rows.append(dict(Model=NAMES[k], mean_pi_test=round(zt.pi.mean(), 4), realised_freq_test=round(zt.real.mean(), 4),
                     Brier_test=round(br, 5), BSS_test=round(bss, 4)))
    print(rows[-1], flush=True)
pd.DataFrame(rows).to_csv("results/table3_pi_M8000.csv", index=False)
pickle.dump({"signals": sigs}, open("results/signals_pi_M8000.pkl", "wb"))
