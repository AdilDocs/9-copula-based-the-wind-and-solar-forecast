"""Re-run the 2020 stress period with K=3000 simulated years for every policy of Table 4 (common failure histories)."""
import glob, pickle
import numpy as np, pandas as pd, torch, torch.nn as nn
from common import load_data, year_slice, run_policy
from env import sample_availability, MyopicPolicy, Z
from evaluate import SocRule, load_trained, drought_days_mask
from maddpg import DetPolicy, mlp
from ppo_lag import LagAgent, LagPolicy
from risk_sched import RiskPolicy, ALPHAS

K = 3000
d, arr = load_data()
s, n = year_slice(d, 2020)
av = sample_availability(K, n, np.random.default_rng(20200), 1.0)
pols = {
    "Myopic OPF": MyopicPolicy(),
    "FCR-first": SocRule(lambda e, t: np.full(e.B, 0.55), "fcr"),
    "Max-reserve": SocRule(lambda e, t: np.full(e.B, 1.0), "full"),
    "Seasonal": SocRule(lambda e, t: np.where(np.isin(arr["month"][t], [11, 12, 1, 2]), 1.0, 0.55), "season"),
}
for f in sorted(glob.glob("runs/main_z-none_s[0-9].pt")):
    pols["MAPPO_" + f[-5:-3]] = load_trained(f, arr)[0]
for f in sorted(glob.glob("runs/comp_ppolag_s*.pt")):
    ck = torch.load(f, weights_only=False); ag = LagAgent(ck["D"]); ag.load_state_dict(ck["state"])
    pols["PPOLag_" + f[-5:-3]] = LagPolicy(ag)
for f in sorted(glob.glob("runs/comp_maddpg2c_s*.pt")):
    ck = torch.load(f, weights_only=False); a = mlp(ck["D"] + Z, 1, 128, nn.Tanh()); a.load_state_dict(ck["actor"])
    pols["MADDPG2c_" + f[-5:-3]] = DetPolicy(a)
tune = pd.read_csv("results/risk_tuning_2018.csv")
alpha = tune[tune.copula == "t"].sort_values("TC").iloc[0].alpha
pols["Proposed"] = RiskPolicy(pickle.load(open("results/risk_ereq.pkl", "rb"))["t"][:, ALPHAS.index(alpha)], "prop")
out = {}
for name, p in pols.items():
    r = run_policy(p, arr, None, s, n, K, np.random.default_rng(0), use_z=False, avail=av)
    e = r["EENS"]
    cov = np.std(e, ddof=1) / np.sqrt(K) / np.mean(e)
    covtc = np.std(r["TC"], ddof=1) / np.sqrt(K) / np.mean(r["TC"])
    out[name] = {k: r[k] for k in ["LOLP", "LOLE", "EENS", "FCR", "TC"]}
    print(name, {k: round(float(np.mean(r[k])), 2) for k in ["LOLE", "EENS", "FCR", "TC"]},
          "beta_EENS %.3f beta_TC %.4f" % (cov, covtc), flush=True)
pickle.dump(out, open("results/stress2020_k3000.pkl", "wb"))
