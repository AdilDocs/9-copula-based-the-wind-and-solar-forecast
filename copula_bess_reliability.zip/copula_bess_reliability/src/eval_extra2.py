"""Evaluate two-critic MADDPG (Riaz & Sajjad 2026-style) and PPO-Lagrangian (Wu et al. 2024-style)."""
import glob, pickle
import numpy as np, torch, torch.nn as nn
from common import load_data, year_slice, run_policy
from env import sample_availability, Z
from evaluate import drought_days_mask
from maddpg import DetPolicy, mlp
from ppo_lag import LagAgent, LagPolicy

d, arr = load_data()
pols = {}
for f in sorted(glob.glob("runs/comp_maddpg2c_s*.pt")):
    ck = torch.load(f, weights_only=False)
    a = mlp(ck["D"] + Z, 1, 128, nn.Tanh()); a.load_state_dict(ck["actor"])
    pols[f.split("/")[-1][:-3]] = DetPolicy(a)
for f in sorted(glob.glob("runs/comp_ppolag_s*.pt")):
    ck = torch.load(f, weights_only=False)
    ag = LagAgent(ck["D"]); ag.load_state_dict(ck["state"])
    pols[f.split("/")[-1][:-3]] = LagPolicy(ag)
out = {}
for per, (y, K, seed) in {"test2019": (2019, 300, 2019), "stress2020": (2020, 200, 2020)}.items():
    s, n = year_slice(d, y)
    mask = drought_days_mask(d, s, n)
    av = sample_availability(K, n, np.random.default_rng(seed), 1.0)
    out[per] = {}
    for name, p in pols.items():
        r = run_policy(p, arr, None, s, n, K, np.random.default_rng(0), use_z=False, avail=av)
        r["EENS_drought"] = r["ens_t"][mask].sum() * 8760.0 / n
        out[per][name] = r
        print(per, name, {k: round(float(np.mean(r[k])), 2) for k in ["LOLE", "EENS", "FCR", "TC"]}, flush=True)
pickle.dump(out, open("results/smcs_extra2.pkl", "wb"))
