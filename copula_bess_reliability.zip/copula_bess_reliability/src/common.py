import numpy as np, pandas as pd, pickle
from env import FeederEnv, sample_availability
from config import COST

def load_data():
    d = pd.read_pickle("data/de_hourly.pkl")
    arr = {k: d[k].values.astype(np.float64) for k in ["load", "wind", "solar", "price"]}
    for k in ["hour", "doy", "dow", "year", "month"]:
        arr[k] = d[k].values.astype(np.int64)
    return d, arr

def load_z(kind, d):
    s = pickle.load(open("results/signals.pkl", "rb"))["signals"][kind]
    s = s.reindex(d.index)
    rho = s["rho"].fillna(0).values
    pi = s["pi"].ffill().fillna(0.2).values
    return np.column_stack([rho * 3.0, (pi - 0.2) / 0.2])   # scaled features

def year_slice(d, y0, y1=None):
    y1 = y1 or y0
    idx = np.where((d.year >= y0).values & (d.year <= y1).values)[0]
    return idx[0], len(idx)

def run_policy(policy, arr, z, start, T, K, rng, use_z=True, rate_mult=1.0, avail=None, scale=None, record=False,
               starts=None):
    """SMCS over K sampled failure histories on the chronological series [start, start+T). Returns per-sample stats."""
    if avail is None:
        avail = sample_availability(K, T, rng, rate_mult)
    env = FeederEnv(arr, z, B=K, ep_len=T, starts=np.full(K, start) if starts is None else starts, avail=avail, soc0=0.6,
                    use_z=use_z, rng=rng, scale=scale)
    obs = env.reset()
    ens = np.zeros((K, T)); op = np.zeros(K); curt = np.zeros(K); fcr = np.zeros(K); rec = []
    done = False
    while not done:
        a = policy.act(env) if not hasattr(policy, "act_obs") else policy.act_obs(obs)
        obs, r, done, info = env.step(a)
        k = env.k - 1
        ens[:, k] = info["ens"]; op += info["op_cost"]; curt += info["curt"]; fcr += info["fcr"]
        if record:
            rec.append({"soc": info["soc"][0].copy(), "ens": info["ens"][0], "P": info["P"][0].copy()})
    hrs = T / 8760.0
    out = dict(LOLP=(ens > 1e-6).mean(1), LOLE=(ens > 1e-6).sum(1) / hrs, EENS=ens.sum(1) / hrs,
               OPC=op / hrs / 1000.0, CURT=curt / hrs, FCR=fcr / hrs / 1000.0)
    out["TC"] = out["OPC"] + COST["voll"] * out["EENS"] / 1000.0
    out["ens_t"] = ens.mean(0)
    out["lol_t"] = (ens > 1e-6).mean(0)
    if record:
        out["rec"] = rec
    return out
