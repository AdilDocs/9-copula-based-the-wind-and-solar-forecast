"""Stage 1 production run: fit 5 copula variants on 2015-2017, evaluate (Table 3), compute z_t for 2015-2020."""
import pickle, time, json
import numpy as np, pandas as pd
from scipy import stats
from stage1 import *
from config import FEEDER, SIG

d = pd.read_pickle("data/de_hourly.pkl")
tr = d[d.year <= 2017]
va = d[d.year == 2018]
te = d[d.year == 2019]
H, L, q = SIG["H"], SIG["L"], SIG["q"]
wW, wS = sum(FEEDER["wind"]), sum(FEEDER["pv"])
wW, wS = wW / (wW + wS), wS / (wW + wS)
base = JointDroughtModel(H=H, qd=q, L=L).fit_marginals(tr)
_, u_tr, v_tr, ok_tr, _, _ = base.residual_pobs(tr)
dte = d[(d.year >= 2018) & (d.year <= 2019)]
_, u_te, v_te, ok_te, _, _ = base.residual_pobs(dte)
emp_tr = np.mean((u_tr[ok_tr] < .1) & (v_tr[ok_tr] < .1)) / .1
emp_te = np.mean((u_te[ok_te] < .1) & (v_te[ok_te] < .1)) / .1
rows, sigs = [], {}
for k in KINDS:
    t0 = time.time()
    m = JointDroughtModel(H=H, qd=q, L=L)
    m.__dict__.update(base.__dict__)
    m.fit_copula(tr, k)
    c = m.cop
    n = ok_tr.sum()
    ll_tr, ll_te = c.loglik(u_tr[ok_tr], v_tr[ok_tr]), c.loglik(u_te[ok_te], v_te[ok_te])
    z = combined_shortage(m, d, wW, wS, q=SIG["q_short"], d_train=tr)
    sigs[k] = z
    zt = z[(z.index.year >= 2018) & (z.index.year <= 2019)].dropna()
    br = np.mean((zt.pi - zt.real) ** 2)
    clim = z[z.index.year <= 2017].real.mean()
    bss = 1 - br / np.mean((clim - zt.real) ** 2)
    path = c.path(u_tr[ok_tr], v_tr[ok_tr])[:-1] if k != "indep" else np.zeros(1)
    lam = c.lower_tail(path, 0.1) if k != "indep" else 0.1
    rows.append(dict(Model=NAMES[k], k=c.npar, LL_train=round(ll_tr, 1), AIC=round(-2 * ll_tr + 2 * c.npar, 1),
                     BIC=round(-2 * ll_tr + np.log(n) * c.npar, 1), LL_test=round(ll_te, 1),
                     lamL_model=round(lam, 4), lamL_emp_train=round(emp_tr, 4), lamL_emp_test=round(emp_te, 4),
                     mean_pi_test=round(zt.pi.mean(), 4), realised_freq_test=round(zt.real.mean(), 4),
                     Brier_test=round(br, 5), BSS_test=round(bss, 4),
                     params=json.dumps({a: round(float(b), 4) for a, b in c.describe().items()}),
                     fit_sec=round(time.time() - t0, 1)))
    print(rows[-1], flush=True)
pd.DataFrame(rows).to_csv("results/table3_copula_fit.csv", index=False)
pickle.dump({"signals": sigs, "r2": base.r2}, open("results/signals.pkl", "wb"))
print("marginal R2", base.r2)
