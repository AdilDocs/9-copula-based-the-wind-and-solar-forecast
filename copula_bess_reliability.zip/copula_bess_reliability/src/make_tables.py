"""Builds the result tables of the paper from the experiment outputs in results/.

  Table (dependence models)  : results/table3_dependence_models.csv (written by run_signals.py + run_scenarios.py)
  Table (comparison)         : 2019 test year (K=300) and 2020 stress period (K=800), all policies
  Table (Stage-1 models)     : risk-constrained scheduler with the copula replaced by alternative uncertainty models
  Table (sensitivity)        : total cost of all policies in the nine sensitivity settings

Paper notation vs. code: risk level delta = `alpha` in the code; reserve revenue r = `FCR`; CV = `beta`.
Output: results/paper_table_*.csv
"""
import pickle
import numpy as np
import pandas as pd
from scipy import stats

R = "results/"


def load(name):
    return pickle.load(open(R + name, "rb"))


def mean_over_seeds(runs, key):
    """Per-simulated-year average over training seeds (array of length K)."""
    return np.mean([np.asarray(r[key]) for r in runs], axis=0)


# ------------------------------------------------------------------------------------------------ comparison
def comparison():
    ev = load("smcs_eval.pkl")["results"]["test2019"]
    ex = load("smcs_extra2.pkl")["test2019"]
    rk = load("smcs_risk.pkl")["test2019"]
    st = load("stress2020_k3000.pkl")
    pol19 = {
        "Myopic OPF": [ev["Myopic OPF"]],
        "FCR-first (SOC 0.55)": [ev["Rule-based (FCR-first, SOC 0.55)"]],
        "Max-reserve (SOC 1.0)": [ev["Rule-based (max-reserve, SOC 1.0)"]],
        "Seasonal rule": [ev["Rule-based (seasonal reserve)"]],
        "PPO (single agent)": [ev[k] for k in ev if k.startswith("comp_z-dt_central_s")],
        "MAPPO": [ev[k] for k in ev if k.startswith("main_z-none_s")],
        "Constrained PPO": [ex[k] for k in ex if k.startswith("comp_ppolag_s")],
        "Two-critic MADDPG": [ex[k] for k in ex if k.startswith("comp_maddpg2c_s")],
        "Proposed": [rk["risk_t"]],
    }
    pol20 = {
        "Myopic OPF": [st["Myopic OPF"]], "FCR-first (SOC 0.55)": [st["FCR-first"]],
        "Max-reserve (SOC 1.0)": [st["Max-reserve"]], "Seasonal rule": [st["Seasonal"]],
        "PPO (single agent)": None,
        "MAPPO": [st[k] for k in st if k.startswith("MAPPO_")],
        "Constrained PPO": [st[k] for k in st if k.startswith("PPOLag_")],
        "Two-critic MADDPG": [st[k] for k in st if k.startswith("MADDPG2c_")],
        "Proposed": [st["Proposed"]],
    }
    rows = []
    for name, runs in pol19.items():
        row = {"Policy": name,
               "LOLP_x1e3": 1e3 * float(np.mean(mean_over_seeds(runs, "LOLP"))),
               "LOLE_h/yr": float(np.mean(mean_over_seeds(runs, "LOLE"))),
               "EENS_MWh/yr": float(np.mean(mean_over_seeds(runs, "EENS"))),
               "EENS_drought_MWh/yr": float(np.mean([np.mean(r["EENS_drought"]) for r in runs])),
               "Reserve_kEUR/yr": float(np.mean(mean_over_seeds(runs, "FCR"))),
               "TC2019_kEUR/yr": float(np.mean(mean_over_seeds(runs, "TC")))}
        r20 = pol20[name]
        row["EENS2020_MWh/yr"] = float(np.mean(mean_over_seeds(r20, "EENS"))) if r20 else np.nan
        row["TC2020_kEUR/yr"] = float(np.mean(mean_over_seeds(r20, "TC"))) if r20 else np.nan
        rows.append(row)
    df = pd.DataFrame(rows)
    b19, b20 = df["TC2019_kEUR/yr"].min(), df["TC2020_kEUR/yr"].min()
    df["Worst-case gap_%"] = 100 * np.maximum(df["TC2019_kEUR/yr"] / b19 - 1, df["TC2020_kEUR/yr"] / b20 - 1)
    # paired Wilcoxon signed-rank tests of the proposed scheduler vs. every policy (per simulated year)
    p19, p20 = [], []
    for name in df.Policy:
        if name == "Proposed":
            p19.append(np.nan); p20.append(np.nan); continue
        a, b = mean_over_seeds(pol19["Proposed"], "TC"), mean_over_seeds(pol19[name], "TC")
        p19.append(stats.wilcoxon(a, b).pvalue)
        if pol20[name]:
            a, b = mean_over_seeds(pol20["Proposed"], "TC"), mean_over_seeds(pol20[name], "TC")
            p20.append(stats.wilcoxon(a, b).pvalue)
        else:
            p20.append(np.nan)
    df["p_TC2019_vs_proposed"], df["p_TC2020_vs_proposed"] = p19, p20
    df.to_csv(R + "paper_table_comparison.csv", index=False, float_format="%.4g")
    return df


# ------------------------------------------------------------------------------------------------ Stage-1 models
def stage1_models():
    names = {"clim": "Climatological ensemble", "recent": "Recent-history ensemble", "knn": "Analog ensemble",
             "linqr": "Linear quantile regression", "gbm": "Gradient-boosted quantile regression",
             "dqn": "Deep quantile regression"}
    alt_t = pd.read_csv(R + "alt_tuning_2018.csv")
    alt = load("smcs_alt.pkl")
    rows = []
    for k, nm in names.items():
        rows.append({"Model": nm, "TC_val2018": alt_t[alt_t.model == k].TC.min(),
                     "TC_test2019": float(np.mean(alt["test2019"][k]["TC"])),
                     "TC_stress2020": float(np.mean(alt["stress2020"][k]["TC"]))})
    cf_t = pd.read_csv(R + "conformal_tuning_2018.csv")
    cf = load("smcs_conformal.pkl")
    rows.append({"Model": "Conformal quantile regression", "TC_val2018": cf_t.TC.min(),
                 "TC_test2019": float(np.mean(cf["test2019"]["TC"])),
                 "TC_stress2020": float(np.mean(cf["stress2020"]["TC"]))})
    rk_t = pd.read_csv(R + "risk_tuning_2018.csv")
    rk = load("smcs_risk.pkl")
    for k, nm in (("indep", "Copula with independence"), ("dt", "Dynamic t copula"), ("t", "Proposed static t copula")):
        rows.append({"Model": nm, "TC_val2018": rk_t[rk_t.copula == k].TC.min(),
                     "TC_test2019": float(np.mean(rk["test2019"]["risk_" + k]["TC"])),
                     "TC_stress2020": float(np.mean(rk["stress2020"]["risk_" + k]["TC"]))})
    df = pd.DataFrame(rows)
    df.to_csv(R + "paper_table_stage1_models.csv", index=False, float_format="%.1f")
    return df


# ------------------------------------------------------------------------------------------------ sensitivity
def sensitivity():
    a, b = load("sensitivity_risk.pkl"), load("sensitivity.pkl")
    settings = [("base", 1.0)] + [(p, v) for p in ("re", "bess", "fail", "load")
                                  for v in {"re": (0.75, 1.25), "bess": (0.75, 1.25),
                                            "fail": (0.5, 2.0), "load": (0.95, 1.05)}[p]]
    rows = []
    for p, v in settings:
        key = ("re", 1.0) if p == "base" else (p, v)
        tc = {"Myopic OPF": b[key + ("Myopic OPF",)]["TC"],
              "FCR-first": b[key + ("Rule-based (FCR-first)",)]["TC"],
              "Max-reserve": b[key + ("Rule-based (max-reserve)",)]["TC"],
              "MAPPO": float(np.mean([b[k]["TC"] for k in b if k[:2] == key and k[2].startswith("main_z-none")])),
              "Seasonal": a[key + ("Seasonal",)]["TC"],
              "Proposed": a[key + ("Proposed",)]["TC"]}
        best = min(tc.values())
        rows.append({"Setting": "base" if p == "base" else f"{p} x{v}", **tc,
                     "Gap_proposed_%": 100 * (tc["Proposed"] / best - 1),
                     "Rank_proposed": sorted(tc.values()).index(tc["Proposed"]) + 1})
    df = pd.DataFrame(rows)
    df.to_csv(R + "paper_table_sensitivity.csv", index=False, float_format="%.2f")
    return df


if __name__ == "__main__":
    pd.set_option("display.width", 250, "display.max_columns", 30)
    print(comparison().round(2).to_string(index=False), "\n")
    print(stage1_models().round(1).to_string(index=False), "\n")
    s = sensitivity()
    print(s.round(2).to_string(index=False))
    print("mean gap %.2f%%, max gap %.2f%%" % (s["Gap_proposed_%"].mean(), s["Gap_proposed_%"].max()))
