"""Price proxy: day-ahead price as a function of German residual load (load - wind - solar),
calibrated on 2019 DE-LU day-ahead prices (OPSD), applied to all years (prices before Oct-2018 are not in OPSD).
p_t = c0 + c1*RL_t + c2*RL_t^2 + hour-of-day effects."""
import sys
import numpy as np, pandas as pd
SRC = sys.argv[1] if len(sys.argv) > 1 else "data/time_series_60min_singleindex.csv"
c = ["utc_timestamp", "DE_load_actual_entsoe_transparency", "DE_wind_generation_actual",
     "DE_solar_generation_actual", "DE_LU_price_day_ahead"]
r = pd.read_csv(SRC, usecols=c, parse_dates=["utc_timestamp"]).set_index("utc_timestamp").loc["2015":"2020-09-30 23:00"]
r = r.asfreq("h").interpolate(limit=6).ffill().bfill()
d = pd.read_pickle("data/de_hourly.pkl")
RL = (r["DE_load_actual_entsoe_transparency"] - r["DE_wind_generation_actual"] - r["DE_solar_generation_actual"]) / 1000.0
hr = d["hour"].values
X = np.column_stack([np.ones(len(RL)), RL, RL ** 2] + [(hr == h).astype(float) for h in range(1, 24)])
m19 = (d.year == 2019).values
y = r["DE_LU_price_day_ahead"].values
b = np.linalg.lstsq(X[m19], y[m19], rcond=None)[0]
p = X @ b
for yr in (2019, 2020):
    mm = (d.year == yr).values
    print(yr, "R2", 1 - np.var(y[mm] - p[mm]) / np.var(y[mm]), "corr", np.corrcoef(y[mm], p[mm])[0, 1])
d["price"] = np.clip(p, 0, None)          # EUR/MWh
d["price_actual"] = y
d.to_pickle("data/de_hourly.pkl")
print(d.groupby("year").price.describe().round(1))
