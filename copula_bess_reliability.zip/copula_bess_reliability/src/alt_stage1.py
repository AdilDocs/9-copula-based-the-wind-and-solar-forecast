"""Alternative Stage-1 models for the risk-constrained reserve scheduler (replacement candidates for the copula).

Every model produces, for each hour t, the battery energy E_req,t to hold, as a function of one risk parameter
(quantile level). The parameter is tuned on 2018 only; 2019 (test) and 2020 (stress) are evaluated with the same
failure histories as all other methods.

  clim     : climatological bootstrap - next-24 h wind/solar trajectories of training days with the same month and
             start hour; load = last-week persistence; quantile of the hindsight reserve recursion
  recent   : recent-history ensemble - next-24 h wind/solar trajectories observed after the same hour on the last
             14 days (information available at t); load = last-week persistence
  knn      : analog ensemble - quantile of the hindsight reserve E* of the k=150 most similar training hours
  gbm      : gradient-boosted quantile regression of E*
  linqr    : linear quantile regression of E*
  dqn      : deep quantile network (MLP, pinball loss, multiple quantiles) of E*
Usage: python alt_stage1.py build | tune | evaluate
"""
import sys, pickle, time
import numpy as np
import pandas as pd
import torch
import torch.nn as nn
from sklearn.ensemble import HistGradientBoostingRegressor
from sklearn.linear_model import QuantileRegressor
from sklearn.neighbors import NearestNeighbors
from sklearn.preprocessing import StandardScaler
from common import load_data, year_slice, run_policy
from env import sample_availability, ETA
from evaluate import drought_days_mask
from risk_sched import RiskPolicy, WCAP, PCAP, LPK, CAP, P_TOT
from conformal_sched import hindsight_need, features

H = 24
QLEV = [0.9, 0.95, 0.98, 0.99, 0.995, 0.999]


def need_from_paths(W, S, Lf):
    """W, S: (n, M, H) capacity factors; Lf: (n, H) load -> (n, M) reserve need."""
    net = LPK * Lf[:, None, :] - WCAP * W - PCAP * S
    deficit = np.maximum(net - CAP, 0)
    head = np.minimum(np.maximum(CAP - net, 0), P_TOT)
    need = np.zeros(W.shape[:2])
    for h in range(H - 1, -1, -1):
        need = np.maximum(0, need + deficit[..., h] / ETA - ETA * head[..., h])
    return need


def scenario_tables(d, kind, M=200, seed=0, chunk=500):
    rng = np.random.default_rng(seed)
    T = len(d)
    w, s, l = d.wind.values, d.solar.values, d.load.values
    idx = np.clip(np.arange(T)[:, None] + np.arange(1, H + 1)[None], 0, T - 1)
    Lf = l[np.clip(idx - 168, 0, None)]
    tr_idx = np.where((d.year <= 2017).values)[0]
    tr_idx = tr_idx[tr_idx < tr_idx.max() - H]
    mon, hr = d.month.values, d.hour.values
    pools = {}
    if kind == "clim":
        for m in range(1, 13):
            for h in range(24):
                pools[(m, h)] = tr_idx[(mon[tr_idx] == m) & (hr[tr_idx] == h)]
    out = np.zeros((T, len(QLEV)), np.float32)
    for c0 in range(0, T, chunk):
        ts = np.arange(c0, min(T, c0 + chunk))
        if kind == "clim":
            starts = np.stack([rng.choice(pools[(mon[t], hr[t])], M) for t in ts])
        else:   # recent: same hour on the previous 14 days (trajectory fully observed by time t)
            lags = 24 * np.arange(2, 16)
            starts = np.clip(ts[:, None] - lags[None], 0, None)
            starts = np.repeat(starts, M // len(lags) + 1, 1)[:, :M]
        sidx = starts[..., None] + np.arange(1, H + 1)[None, None]
        need = need_from_paths(w[sidx], s[sidx], Lf[ts])
        out[ts] = np.quantile(need, QLEV, axis=1).T
    return out


def pinball_mlp(Xtr, ytr, X, seed=0, epochs=40):
    torch.manual_seed(seed)
    sc = StandardScaler().fit(Xtr)
    xt = torch.tensor(sc.transform(Xtr), dtype=torch.float32)
    yt = torch.tensor(ytr, dtype=torch.float32)[:, None]
    q = torch.tensor(QLEV, dtype=torch.float32)[None]
    net = nn.Sequential(nn.Linear(xt.shape[1], 128), nn.ReLU(), nn.Linear(128, 128), nn.ReLU(),
                        nn.Linear(128, len(QLEV)))
    opt = torch.optim.Adam(net.parameters(), lr=1e-3)
    for ep in range(epochs):
        perm = torch.randperm(len(xt))
        for i in range(0, len(xt), 512):
            b = perm[i:i + 512]
            e = yt[b] - net(xt[b])
            loss = torch.maximum(q * e, (q - 1) * e).mean()
            opt.zero_grad(); loss.backward(); opt.step()
    with torch.no_grad():
        p = net(torch.tensor(sc.transform(X), dtype=torch.float32)).numpy()
    return np.maximum(np.sort(p, 1), 0)   # enforce non-crossing quantiles


def main(cmd):
    d, arr = load_data()
    if cmd == "build":
        y = hindsight_need(d)
        X = features(d).values
        tr = (d.year <= 2017).values
        tabs = {}
        for kind in ("clim", "recent"):
            t0 = time.time(); tabs[kind] = scenario_tables(d, kind); print(kind, round(time.time() - t0), flush=True)
        t0 = time.time()
        sc = StandardScaler().fit(X[tr])
        nn_ = NearestNeighbors(n_neighbors=150).fit(sc.transform(X[tr]))
        _, ind = nn_.kneighbors(sc.transform(X))
        tabs["knn"] = np.quantile(y[tr][ind], QLEV, axis=1).T.astype(np.float32)
        print("knn", round(time.time() - t0), flush=True)
        t0 = time.time()
        tabs["gbm"] = np.stack([np.maximum(HistGradientBoostingRegressor(
            loss="quantile", quantile=q, max_iter=400, learning_rate=0.05, max_leaf_nodes=31, min_samples_leaf=40,
            random_state=0).fit(X[tr], y[tr]).predict(X), 0) for q in QLEV], 1)
        print("gbm", round(time.time() - t0), flush=True)
        t0 = time.time()
        sub = np.where(tr)[0][::3]
        sc2 = StandardScaler().fit(X[tr])
        tabs["linqr"] = np.stack([np.maximum(QuantileRegressor(quantile=q, alpha=1e-4, solver="highs").fit(
            sc2.transform(X[sub]), y[sub]).predict(sc2.transform(X)), 0) for q in QLEV], 1)
        print("linqr", round(time.time() - t0), flush=True)
        t0 = time.time()
        tabs["dqn"] = pinball_mlp(X[tr], y[tr], X)
        print("dqn", round(time.time() - t0), flush=True)
        for k, v in tabs.items():
            for j, q in enumerate(QLEV):
                c = np.mean(y[(d.year == 2018).values] <= v[(d.year == 2018).values, j])
                print(f"  {k} q={q}: 2018 coverage {c:.4f}  mean E_req {v[:, j].mean():.2f}")
        pickle.dump(tabs, open("results/alt_ereq.pkl", "wb"))
        return
    tabs = pickle.load(open("results/alt_ereq.pkl", "rb"))
    if cmd == "tune":
        s, n = year_slice(d, 2018)
        av = sample_availability(32, n, np.random.default_rng(1234), 1.0)
        rows = []
        for k, tab in tabs.items():
            for j, q in enumerate(QLEV):
                r = run_policy(RiskPolicy(tab[:, j], k), arr, None, s, n, 32, np.random.default_rng(0), use_z=False, avail=av)
                rows.append(dict(model=k, q=q, **{m: float(np.mean(r[m])) for m in ["LOLE", "EENS", "FCR", "TC"]}))
                print(rows[-1], flush=True)
        pd.DataFrame(rows).to_csv("results/alt_tuning_2018.csv", index=False)
        return
    if cmd == "evaluate":
        tune = pd.read_csv("results/alt_tuning_2018.csv")
        out = {}
        for per, (yr, K, seed) in {"test2019": (2019, 300, 2019), "stress2020": (2020, 200, 2020)}.items():
            s, n = year_slice(d, yr)
            mask = drought_days_mask(d, s, n)
            av = sample_availability(K, n, np.random.default_rng(seed), 1.0)
            out[per] = {}
            for k, tab in tabs.items():
                best = tune[tune.model == k].sort_values("TC").iloc[0]
                j = QLEV.index(best.q)
                r = run_policy(RiskPolicy(tab[:, j], k), arr, None, s, n, K, np.random.default_rng(0), use_z=False, avail=av)
                r["EENS_drought"] = r["ens_t"][mask].sum() * 8760.0 / n
                r["q"] = best.q
                out[per][k] = r
                print(per, k, "q", best.q, {m: round(float(np.mean(r[m])), 2)
                                           for m in ["LOLP", "LOLE", "EENS", "EENS_drought", "FCR", "TC"]}, flush=True)
        pickle.dump(out, open("results/smcs_alt.pkl", "wb"))


if __name__ == "__main__":
    main(sys.argv[1])
