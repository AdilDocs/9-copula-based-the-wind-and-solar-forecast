"""Sensitivity analysis for the proposed risk-constrained scheduler and the seasonal rule
(same settings as sensitivity.py: 2019, K=64, failure histories seed 77). The scheduler is model-based, so its
reserve table is recomputed with the modified system parameters; alpha is kept at the value selected on 2018."""
import pickle
import numpy as np
import pandas as pd
import risk_sched as rs
from stage1 import JointDroughtModel
from config import FEEDER, SIG
from common import load_data, year_slice, run_policy
from env import sample_availability
from evaluate import SocRule

K = 64
d, arr = load_data()
s, n = year_slice(d, 2019)
tr = d[d.year <= 2017]
m = JointDroughtModel(H=24, qd=SIG["q"], L=SIG["L"]).fit_marginals(tr)
m.fit_copula(tr, "t")
clim = tr.groupby(["month", "hour"]).solar.mean().unstack().values
tune = pd.read_csv("results/risk_tuning_2018.csv")
alpha = tune[tune.copula == "t"].sort_values("TC").iloc[0].alpha
j = rs.ALPHAS.index(alpha)
base = dict(WCAP=rs.WCAP, PCAP=rs.PCAP, LPK=rs.LPK, CAP=rs.CAP, P_TOT=rs.P_TOT)
base_tab = pickle.load(open("results/risk_ereq.pkl", "rb"))["t"][:, j]
grid = {"re": [0.75, 1.0, 1.25], "bess": [0.75, 1.0, 1.25], "fail": [0.5, 1.0, 2.0], "load": [0.95, 1.0, 1.05]}
season = SocRule(lambda e, t: np.where(np.isin(arr["month"][t], [11, 12, 1, 2]), 1.0, 0.55), "season")
out = {}
for par, vals in grid.items():
    for v in vals:
        for k, b in base.items():
            setattr(rs, k, b)
        if par == "re":
            rs.WCAP, rs.PCAP = base["WCAP"] * v, base["PCAP"] * v
        if par == "bess":
            rs.P_TOT = base["P_TOT"] * v
        if par == "load":
            rs.LPK = base["LPK"] * v
        if par in ("re", "bess", "load") and v != 1.0:
            tab = rs.ereq_table(m, d, clim)[:, j]
        else:
            tab = base_tab
        rm = v if par == "fail" else 1.0
        av = sample_availability(K, n, np.random.default_rng(77), rm)
        sc = {"re": v} if par == "re" else {"bess": v} if par == "bess" else {"load": v} if par == "load" else None
        for name, pol in (("Proposed", rs.RiskPolicy(tab, "prop")), ("Seasonal", season)):
            r = run_policy(pol, arr, None, s, n, K, np.random.default_rng(0), use_z=False, avail=av, scale=sc)
            out[(par, v, name)] = {k: float(np.mean(r[k])) for k in ["LOLE", "EENS", "FCR", "TC"]}
            print(par, v, name, out[(par, v, name)], flush=True)
pickle.dump(out, open("results/sensitivity_risk.pkl", "wb"))
