"""Stage 2/3 environment: three-zone radial feeder with wind, PV and BESS agents.

Topology (radial chain):  Supply -- [T1 || T2] -- L1 -- Z1 -- L2 -- Z2 -- L3 -- Z3
 * import limit = tr_cap * (#transformers in service) if the supply point is up, else 0 (islanding)
 * export limit = export_cap (reverse power flow / voltage-rise limit), 0 when disconnected
 * a failed line section isolates all downstream zones; they run as an island with their own DG + BESS
Each zone has one BESS agent. Action a_i in [-1,1] -> BESS power a_i * Pmax_i (+ discharge, - charge).

Safety / feasibility layer (applied to every action, every step):
 1. clip to power and SOC limits
 2. compute the minimum load-shedding / curtailment dispatch on the radial network (exact for a chain)
 3. charging that would cause load shedding is scaled back (bisection) -> charging never causes shedding
 4. discharging that would only be curtailed is scaled back
"""
import numpy as np
from config import FEEDER, COST, REL

Z = FEEDER["zones"]
LPK = np.array(FEEDER["load_peak"])
WCAP = np.array(FEEDER["wind"])
PCAP = np.array(FEEDER["pv"])
BP = np.array(FEEDER["bess_p"])
BE = np.array(FEEDER["bess_e"])
ETA = FEEDER["eta"]
SMIN, SMAX = FEEDER["soc_min"], FEEDER["soc_max"]
LCAP = np.array(FEEDER["line_cap"])

# components: 0 supply, 1 T1, 2 T2, 3 L1, 4 L2, 5 L3
COMP_RATE = np.array([REL["supply"][0], REL["trafo"][0], REL["trafo"][0]] +
                     [REL["line_per_km"][0] * l for l in FEEDER["line_len"]])
COMP_MTTR = np.array([REL["supply"][1], REL["trafo"][1], REL["trafo"][1]] + [REL["line_per_km"][1]] * 3)


def sample_availability(B, T, rng, rate_mult=1.0):
    """Sequential up/down histories (exponential TTF / TTR). Returns bool array (B, T, 6) True = in service."""
    nc = len(COMP_RATE)
    up = np.ones((B, T, nc), bool)
    lam = COMP_RATE * rate_mult / 8760.0
    for c in range(nc):
        for b in range(B):
            t = rng.exponential(1 / lam[c])  # all components in service at the start of each simulated year
            while t < T:
                r = rng.exponential(COMP_MTTR[c])
                up[b, int(t):min(T, int(np.ceil(t + r))), c] = False
                t = t + r + rng.exponential(1 / lam[c])
    return up


def network_limits(av):
    """av: (B, 6) bool -> import cap (B,), export cap (B,), line caps (B,3)"""
    ntr = av[:, 1].astype(float) + av[:, 2].astype(float)
    ci = FEEDER["tr_cap"] * ntr * av[:, 0]
    ce = np.minimum(FEEDER["export_cap"], ci)
    lc = LCAP[None] * av[:, 3:6]
    return ci, ce, lc


def _dispatch(n, D, R, ci, ce, lc):
    """Exact min-shed / min-curtail dispatch on the chain.
    n: (B,3) net demand after BESS; D: loads (B,3) (max sheddable); R: RE available (B,3) (max curtailable).
    Returns shed (B,3), curt (B,3), import (B,)."""
    B = n.shape[0]
    shed = np.zeros((B, Z))
    curt = np.zeros((B, Z))
    g = np.zeros(B)
    for k in range(Z - 1, -1, -1):
        g = g + n[:, k]
        if k == 0:
            up = np.minimum(lc[:, 0], ci)
            lo = -np.minimum(lc[:, 0], ce)
        else:
            up = lc[:, k]
            lo = -lc[:, k]
        ex = np.maximum(g - up, 0.0)
        for j in range(k, Z):  # shed at node k first, then downstream
            s = np.minimum(ex, D[:, j] - shed[:, j])
            shed[:, j] += s
            ex -= s
        de = np.maximum(lo - g, 0.0)
        for j in range(k, Z):
            c = np.minimum(de, R[:, j] - curt[:, j])
            curt[:, j] += c
            de -= c
        g = np.clip(g, lo, up)
    return shed, curt, g


def dispatch(Pb, D, R, ci, ce, lc, iters=12):
    """Safety layer: returns projected BESS power, shed, curt, import."""
    chg = np.minimum(Pb, 0.0)
    dis = np.maximum(Pb, 0.0)
    s0, _, _ = _dispatch(D - R - dis, D, R, ci, ce, lc)
    s1, _, _ = _dispatch(D - R - dis - chg, D, R, ci, ce, lc)
    bad = s1.sum(1) > s0.sum(1) + 1e-6
    if bad.any():
        lo = np.zeros(bad.sum())
        hi = np.ones(bad.sum())
        Db, Rb, cib, ceb, lcb, disb, chgb = D[bad], R[bad], ci[bad], ce[bad], lc[bad], dis[bad], chg[bad]
        s0b = s0[bad].sum(1)
        for _ in range(iters):
            mid = (lo + hi) / 2
            s, _, _ = _dispatch(Db - Rb - disb - chgb * mid[:, None], Db, Rb, cib, ceb, lcb)
            okm = s.sum(1) <= s0b + 1e-6
            lo = np.where(okm, mid, lo)
            hi = np.where(okm, hi, mid)
        chg[bad] = chgb * lo[:, None]
    _, c0, _ = _dispatch(D - R - chg, D, R, ci, ce, lc)
    _, c1, _ = _dispatch(D - R - chg - dis, D, R, ci, ce, lc)
    bad = c1.sum(1) > c0.sum(1) + 1e-6
    if bad.any():
        lo = np.zeros(bad.sum())
        hi = np.ones(bad.sum())
        Db, Rb, cib, ceb, lcb, disb, chgb = D[bad], R[bad], ci[bad], ce[bad], lc[bad], dis[bad], chg[bad]
        c0b = c0[bad].sum(1)
        for _ in range(iters):
            mid = (lo + hi) / 2
            _, c, _ = _dispatch(Db - Rb - chgb - disb * mid[:, None], Db, Rb, cib, ceb, lcb)
            okm = c.sum(1) <= c0b + 1e-6
            lo = np.where(okm, mid, lo)
            hi = np.where(okm, hi, mid)
        dis[bad] = disb * lo[:, None]
    Pb2 = chg + dis
    shed, curt, imp = _dispatch(D - R - Pb2, D, R, ci, ce, lc)
    return Pb2, shed, curt, imp


class FeederEnv:
    """Vectorised over B parallel trajectories. Data arrays are hourly series (T_total,)."""

    def __init__(self, data, z=None, B=64, ep_len=168, rng=None, rate_mult=1.0, use_z=True,
                 starts=None, avail=None, soc0=None, scale=None):
        self.d = data          # dict of np arrays: load, wind, solar, price, hour, doy, dow
        self.z = z             # (T_total, nz) or None
        self.B, self.ep_len = B, ep_len
        self.rng = rng or np.random.default_rng(0)
        self.rate_mult = rate_mult
        self.use_z = use_z and z is not None
        self.fixed_starts, self.fixed_avail, self.fixed_soc0 = starts, avail, soc0
        self.sc = scale or {}
        self.lpk, self.wcap, self.pcap = LPK * self.sc.get("load", 1.0), WCAP * self.sc.get("re", 1.0), PCAP * self.sc.get("re", 1.0)
        self.be = BE * self.sc.get("bess", 1.0)
        self.bp = BP * self.sc.get("bess", 1.0)
        self.pmean = 40.0

    @property
    def obs_dim(self):
        return 15 + (self.z.shape[1] if self.use_z else 0)

    @property
    def state_dim(self):
        return self.obs_dim * Z

    def reset(self):
        T = len(self.d["load"])
        if self.fixed_starts is not None:
            self.t0 = np.asarray(self.fixed_starts)
        else:
            self.t0 = self.rng.integers(0, T - self.ep_len - 1, self.B)
        if self.fixed_avail is not None:
            self.avail = self.fixed_avail
        else:
            self.avail = sample_availability(self.B, self.ep_len + 1, self.rng, self.rate_mult)
        self.soc = (self.fixed_soc0 if self.fixed_soc0 is not None
                    else self.rng.uniform(0.3, 1.0, (self.B, Z)))
        self.soc = np.broadcast_to(self.soc, (self.B, Z)).copy()
        self.k = 0
        return self._obs()

    def _exo(self):
        t = self.t0 + self.k
        D = self.d["load"][t][:, None] * self.lpk[None]
        R = self.d["wind"][t][:, None] * self.wcap[None] + self.d["solar"][t][:, None] * self.pcap[None]
        return t, D, R

    def _obs(self):
        t, D, R = self._exo()
        av = self.avail[:, self.k]
        ci, ce, lc = network_limits(av)
        conn = np.stack([np.minimum(ci, lc[:, 0]) > 0,
                         (np.minimum(ci, lc[:, 0]) > 0) & (lc[:, 1] > 0),
                         (np.minimum(ci, lc[:, 0]) > 0) & (lc[:, 1] > 0) & (lc[:, 2] > 0)], 1).astype(float)
        hr = self.d["hour"][t]
        doy = self.d["doy"][t]
        o = np.zeros((self.B, Z, self.obs_dim))
        o[..., 0] = self.soc
        o[..., 1] = D / self.lpk[None]
        o[..., 2] = (self.d["wind"][t])[:, None].repeat(Z, 1) * (self.wcap[None] > 0)
        o[..., 3] = (self.d["solar"][t])[:, None].repeat(Z, 1) * (self.pcap[None] > 0)
        o[..., 4] = (D - R) / self.lpk[None]
        o[..., 5] = ((self.d["price"][t] - self.pmean) / 15.0)[:, None]
        o[..., 6] = np.sin(2 * np.pi * hr / 24)[:, None]
        o[..., 7] = np.cos(2 * np.pi * hr / 24)[:, None]
        o[..., 8] = np.sin(2 * np.pi * doy / 366)[:, None]
        o[..., 9] = np.cos(2 * np.pi * doy / 366)[:, None]
        o[..., 10] = (self.d["dow"][t] >= 5)[:, None]
        o[..., 11] = conn
        o[..., 12] = (ci / (2 * FEEDER["tr_cap"]))[:, None]
        o[..., 13] = self.be[None] / 6.0
        o[..., 14] = ((np.minimum(ci, lc[:, 0]) - D.sum(1) + R.sum(1)) / self.lpk.sum())[:, None]  # broadcast system margin
        if self.use_z:
            o[..., 15:] = self.z[t][:, None, :]
        return o

    def soc_target_to_power(self, a):
        """Agent action = SOC set-point tau in [SMIN, SMAX]; BESS moves towards it within one hour.
        Emergency support (part of the safety layer): whenever load would otherwise be shed, the BESS
        discharges the required amount regardless of its set-point."""
        tau = SMIN + (SMAX - SMIN) * (np.clip(a, -1, 1) + 1) / 2
        p = (self.soc - tau) * self.be[None]          # >0 discharge, <0 charge (MWh over 1 h)
        p = np.where(p > 0, p * ETA, p / ETA)
        a_pow = np.clip(p / self.bp[None], -1, 1)
        disc, _ = _needs(self)
        return np.where(disc > 1e-9, np.maximum(a_pow, disc / self.bp[None]), a_pow)

    def step(self, a):
        """a: (B, Z) in [-1, 1]. Returns obs, reward (B,), done, info"""
        if getattr(self, "soc_mode", False):
            a = self.soc_target_to_power(a)
        t, D, R = self._exo()
        av = self.avail[:, self.k]
        ci, ce, lc = network_limits(av)
        a = np.clip(a, -1, 1)
        P = a * self.bp[None]
        # SOC limits
        pmax_d = np.maximum((self.soc - SMIN) * self.be[None] * ETA, 0)
        pmax_c = np.maximum((SMAX - self.soc) * self.be[None] / ETA, 0)
        P = np.clip(P, -pmax_c, pmax_d)
        P, shed, curt, imp = dispatch(P, D, R, ci, ce, lc)
        # FCR capacity offered automatically with the headroom left: power headroom and symmetric energy
        # reservation of fcr_tau hours in both directions (start-of-hour SOC)
        e_dn = (self.soc - SMIN) * self.be[None]
        e_up = (SMAX - self.soc) * self.be[None]
        fcr = np.clip(np.minimum(np.minimum(e_dn, e_up) / COST["fcr_tau"], self.bp[None] - np.abs(P)), 0, None)
        fcr = fcr * (np.minimum(ci, lc[:, 0]) > 0)[:, None]   # only while grid-connected
        dis = np.maximum(P, 0)
        chg = -np.minimum(P, 0)
        self.soc = np.clip(self.soc + (chg * ETA - dis / ETA) / self.be[None], 0, 1)
        price = self.d["price"][t]
        energy_cost = price * imp                         # import positive, export negative (revenue)
        cyc_cost = COST["cyc"] * dis.sum(1)
        ens = shed.sum(1)
        voll_cost = COST["voll"] * ens
        fcr_rev = COST["fcr"] * fcr.sum(1)
        cost = energy_cost + cyc_cost + voll_cost - fcr_rev
        info = dict(ens=ens, shed=shed, curt=curt.sum(1), imp=imp, op_cost=energy_cost + cyc_cost - fcr_rev,
                    fcr=fcr_rev,
                    cost=cost, P=P, soc=self.soc.copy(), D=D.sum(1), R=R.sum(1))
        # learning reward: controllable part of the cost (import cost change caused by the BESS)
        ctrl = -price * P.sum(1) + cyc_cost + voll_cost - fcr_rev
        info["ctrl_cost"] = ctrl
        self.k += 1
        done = self.k >= self.ep_len
        obs = self._obs() if (not done or self.avail.shape[1] > self.k) else None
        return obs, -ctrl / 1000.0, done, info


# ------------------------------------------------------------------------------------------------
# Rule-based / myopic baselines operating on the same observation and safety layer
# ------------------------------------------------------------------------------------------------
def _needs(env):
    """Per-zone discharge needed to avoid shedding (myopic), and own-zone RE surplus."""
    t, D, R = env._exo()
    net = D - R
    av = env.avail[:, env.k]
    ci, ce, lc = network_limits(av)
    pmax_d = np.maximum((env.soc - SMIN) * env.be[None] * ETA, 0)
    pmax_d = np.minimum(pmax_d, env.bp[None])
    # zone j is grid-connected if supply path up to j is intact
    path = np.cumprod(np.concatenate([(np.minimum(ci, lc[:, 0]) > 0)[:, None], lc[:, 1:] > 0], 1), 1).astype(bool)
    disc = np.zeros_like(net)
    for grp_mask, cap in ((path, np.minimum(ci, lc[:, 0])), (~path, np.zeros(env.B))):
        need = np.maximum((net * grp_mask).sum(1) - cap, 0)
        avail = (pmax_d * grp_mask).sum(1)
        share = np.where(avail > 0, np.minimum(need / np.maximum(avail, 1e-9), 1.0), 0.0)
        disc += grp_mask * share[:, None] * pmax_d
    # downstream line limits (L2, L3): local deficits beyond line capacity
    for k in (1, 2):
        flow = net[:, k:].sum(1)
        over = np.maximum(flow - lc[:, k], 0) * path[:, k]
        sub = pmax_d[:, k:]
        tot = np.maximum(sub.sum(1), 1e-9)
        disc[:, k:] = np.maximum(disc[:, k:], np.minimum(over / tot, 1.0)[:, None] * sub)
    surplus = np.maximum(-net, 0)
    return disc, surplus


class MyopicPolicy:
    """Myopic min-curtailment dispatch (per-state OPF equivalent): BESS discharges only what is needed
    to avoid load shedding in the current hour; charges only from its own zone's RE surplus."""
    name = "Myopic OPF"

    def act(self, env):
        disc, surplus = _needs(env)
        a = disc / env.bp[None]
        a = np.where(disc > 1e-9, a, -np.minimum(surplus / env.bp[None], 1.0))
        return a


class ReserveRule:
    """Reliability-first rule: keep the BESS as full as possible (charge from the grid whenever there is
    headroom), discharge only what is needed to avoid shedding."""
    name = "Max-reserve rule"

    def act(self, env):
        disc, _ = _needs(env)
        return np.where(disc > 1e-9, disc / env.bp[None], -1.0)


class FCRRule:
    """Industry-style FCR-first rule: steer each BESS to SOC = 0.5 (maximises FCR capacity); discharge only
    what is needed to avoid shedding."""
    name = "Rule-based (FCR-first)"

    def __init__(self, target=0.5):
        self.target = target

    def act(self, env):
        disc, _ = _needs(env)
        a = np.clip((self.target - env.soc) * env.be[None] / env.bp[None], -1, 1) * -1.0
        a = np.clip(-(self.target - env.soc) * env.be[None] / env.bp[None], -1, 1)
        return np.where(disc > 1e-9, disc / env.bp[None], a)


class ArbitrageRule:
    """Price-threshold arbitrage with emergency discharge: charge when the price is below the 30th
    percentile of the previous 7 days, discharge when above the 70th percentile or to avoid shedding."""
    name = "Rule-based (arbitrage)"

    def __init__(self, price):
        p = np.asarray(price)
        import pandas as pd
        s = pd.Series(p)
        self.lo = s.shift(1).rolling(168, min_periods=24).quantile(0.3).bfill().values
        self.hi = s.shift(1).rolling(168, min_periods=24).quantile(0.7).bfill().values

    def act(self, env):
        t, D, R = env._exo()
        p = env.d["price"][t]
        a = np.zeros((env.B, Z))
        a[p < self.lo[t]] = -1.0
        a[p > self.hi[t]] = 1.0
        disc, _ = _needs(env)
        a = np.where(disc > 1e-9, np.maximum(a, disc / env.bp[None]), a)
        return a
