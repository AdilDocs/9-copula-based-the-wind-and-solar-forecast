"""Tiny job queue: runs shell commands from a text file with N parallel workers, skipping finished ones.
Usage: python queue.py jobs.txt 2"""
import subprocess, sys, time, os

jobs = [l.strip() for l in open(sys.argv[1]) if l.strip() and not l.startswith("#")]
N = int(sys.argv[2]) if len(sys.argv) > 2 else 2
os.makedirs("logs", exist_ok=True)
running = []
i = 0
while i < len(jobs) or running:
    running = [(p, c) for p, c in running if p.poll() is None]
    while len(running) < N and i < len(jobs):
        cmd = jobs[i]
        name = cmd.replace(" ", "_").replace("-", "").replace("/", "")[-90:]
        p = subprocess.Popen(cmd + f" > logs/{name}.log 2>&1", shell=True)
        running.append((p, cmd))
        print(time.strftime("%H:%M:%S"), "start", cmd, flush=True)
        i += 1
    time.sleep(5)
print("ALL DONE", flush=True)
