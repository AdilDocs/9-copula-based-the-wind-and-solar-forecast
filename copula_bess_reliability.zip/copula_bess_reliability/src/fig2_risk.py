"""Fig. 2 for the risk-constrained scheduler: (a) copula shortfall probability, (b) SOC trajectories
(2019 replay without failures) of the proposed scheduler, MAPPO and the FCR-first rule."""
import pickle, numpy as np, pandas as pd
from common import load_data, load_z, year_slice, run_policy
from env import sample_availability
from evaluate import SocRule, load_trained
from risk_sched import RiskPolicy, ALPHAS
d, arr = load_data()
s, n = year_slice(d, 2019)
av = sample_availability(1, n, np.random.default_rng(0), 0.0)
tabs = pickle.load(open("results/risk_ereq.pkl", "rb"))
tune = pd.read_csv("results/risk_tuning_2018.csv")
a = tune[tune.copula == "t"].sort_values("TC").iloc[0].alpha
prop = RiskPolicy(tabs["t"][:, ALPHAS.index(a)], "prop")
mappo, _ = load_trained("runs/main_z-none_s0.pt", arr)
fcr = SocRule(lambda e, t: np.full(e.B, 0.55), "fcr")
soc = {}
for nm, p in (("prop", prop), ("mappo", mappo), ("fcr", fcr)):
    r = run_policy(p, arr, None, s, n, 1, np.random.default_rng(0), use_z=False, avail=av, record=True)
    soc[nm] = np.array([x["soc"].mean() for x in r["rec"]])
old = pickle.load(open("results/fig2_traj.pkl", "rb"))
idx = d.index[s:s + n]
a0 = int(np.where(idx == old["start"])[0][0]); b0 = int(np.where(idx == old["end"])[0][0]) + 1
old.update(soc_z=soc["prop"][a0:b0], soc_noz=soc["mappo"][a0:b0], soc_fcr=soc["fcr"][a0:b0])
pickle.dump(old, open("results/fig2_traj_risk.pkl", "wb"))
print("ok", a)
