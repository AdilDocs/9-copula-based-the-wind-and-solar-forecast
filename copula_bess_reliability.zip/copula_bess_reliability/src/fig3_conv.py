"""Fig. 3: SMCS convergence of the proposed scheduler (2019 test year, 300 simulated years)."""
import pickle, numpy as np
import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
from make_report import C
X = pickle.load(open("results/smcs_risk.pkl", "rb"))
X["stress2020"] = {"risk_t": pickle.load(open("results/stress2020_k3000.pkl", "rb"))["Proposed"]}
fig, ax = plt.subplots(1, 2, figsize=(7.2, 2.7))
out = {}
for per, col, lab in (("test2019", C[4], "2019 (test)"), ("stress2020", C[0], "2020 (stress)")):
    e = np.asarray(X[per]["risk_t"]["EENS"])
    n = np.arange(1, len(e) + 1)
    m = np.cumsum(e) / n
    sd = np.array([np.std(e[:k], ddof=1) if k > 1 else np.nan for k in n])
    se = sd / np.sqrt(n)
    cov = se / m * 100
    ax[0].plot(n, m, color=col, label=lab)
    ax[0].fill_between(n, m - 1.96 * se, m + 1.96 * se, color=col, alpha=0.15, lw=0)
    ax[1].plot(n, cov, color=col, label=lab)
    k5 = int(np.argmax((cov <= 5) & (n > 10))) + 1
    out[per] = dict(K=len(e), mean=m[-1], ci=1.96 * se[-1], cov_final=cov[-1], k_at_5=k5)
ax[0].set_xlabel("Simulated years"); ax[0].set_ylabel("EENS [MWh/yr]")
ax[0].set_title("(a) Running mean of EENS (95% CI)", loc="left", fontsize=9)
ax[0].legend(frameon=False, fontsize=7)
ax[1].axhline(5, color="#8a8984", lw=0.9, ls="--"); ax[1].text(250, 6.3, r"$\mathrm{CV}^{\max}=5\%$", fontsize=7)
ax[1].set_ylim(0, 25); ax[1].set_xlabel("Simulated years"); ax[1].set_ylabel(r"CV [%]")
ax[1].set_title("(b) Coefficient of variation CV of the EENS estimate", loc="left", fontsize=9)
fig.tight_layout()
fig.savefig("figures/fig3_convergence.png", dpi=300); fig.savefig("figures/fig3_convergence.pdf")
for k, v in out.items(): print(k, {a: round(float(b), 2) for a, b in v.items()})
