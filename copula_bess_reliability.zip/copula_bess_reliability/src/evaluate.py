"""Stage 3: SMCS reliability evaluation with frozen policies (Tables 4-6, Fig. 2b, Fig. 3b data).

For each period K chronological failure/repair histories are sampled once (common random numbers); every
policy is simulated on exactly the same histories and renewable/load trajectories.
Indices per simulated year: LOLP, LOLE [h/yr], EENS [MWh/yr], FCR revenue, operating cost, total cost incl.
VOLL [kEUR/yr]. MADRL variants: each training seed's best-validation checkpoint is evaluated; we report the
mean (and std) over seeds of the K-sample averages, and a paired Wilcoxon test over the K samples.
Usage: python evaluate.py [K_test] [K_stress]
"""
import glob, json, sys, time, pickle, re
import numpy as np
import pandas as pd
import torch
from scipy import stats
from common import load_data, load_z, year_slice, run_policy
from env import MyopicPolicy, sample_availability, FeederEnv, SMIN, SMAX
from mappo import Agent, TorchPolicy, HistWrap

KT = int(sys.argv[1]) if len(sys.argv) > 1 and sys.argv[1].isdigit() else 300
KS = int(sys.argv[2]) if len(sys.argv) > 2 and sys.argv[2].isdigit() else 200
METRICS = ["LOLP", "LOLE", "EENS", "FCR", "OPC", "TC"]


class SocRule:
    def __init__(self, f, name):
        self.f, self.name = f, name

    def act(self, env):
        t = env.t0 + env.k
        tau = self.f(env, t)
        a = 2 * (tau - SMIN) / (SMAX - SMIN) - 1
        return env.soc_target_to_power(np.broadcast_to(np.asarray(a)[:, None], (env.B, 3)).copy())


def load_trained(path, arr):
    ck = torch.load(path, weights_only=False)
    ag = Agent(ck["D"], central=ck["central"], ippo=ck.get("ippo", False))
    ag.load_state_dict(ck["state"])
    ag.eval()
    hist = None
    if ck["hist"]:
        e = FeederEnv(arr, None, B=1)
        hist = HistWrap(arr, e.lpk, e.wcap, e.pcap)
    return TorchPolicy(ag, hist), ck


def drought_days_mask(d, s, n):
    """Hours of the evaluation period that belong to joint wind-solar drought days (daily mean wind AND
    daily mean solar CF below the within-month 20% quantile of the training years)."""
    tr = d[d.year <= 2017]
    ltr = tr.index.tz_convert("Europe/Berlin").normalize()
    dtr = tr.groupby(ltr)[["wind", "solar"]].mean()
    q = dtr.groupby(dtr.index.month).quantile(0.2)
    sub = d.iloc[s:s + n]
    ls = sub.index.tz_convert("Europe/Berlin").normalize()
    dd = sub.groupby(ls)[["wind", "solar"]].transform("mean")
    m = sub.month.values
    return ((dd.wind.values < q.wind.values[m - 1]) & (dd.solar.values < q.solar.values[m - 1]))


def evaluate_period(pols, arr, zmap, s, n, K, seed, mask):
    av = sample_availability(K, n, np.random.default_rng(seed), 1.0)
    out = {}
    for name, (pol, zkey) in pols.items():
        t0 = time.time()
        z = zmap.get(zkey)
        r = run_policy(pol, arr, z, s, n, K, np.random.default_rng(0), use_z=z is not None, avail=av)
        r["EENS_drought"] = r["ens_t"][mask].sum() * 8760.0 / n      # MWh/yr inside drought days
        r["LOLE_drought"] = r["lol_t"][mask].sum() * 8760.0 / n
        out[name] = r
        print(f"  {name:40s} EENS={r['EENS'].mean():7.2f} LOLE={r['LOLE'].mean():6.2f} FCR={r['FCR'].mean():6.1f} "
              f"TC={r['TC'].mean():8.1f}  ({time.time() - t0:.0f}s)", flush=True)
    return out


def main():
    d, arr = load_data()
    kinds = ["indep", "gauss", "t", "dgauss", "dt"]
    zmap = {k: load_z(k, d) for k in kinds}
    pi = zmap["dt"][:, 1] * 0.2 + 0.2
    rules = {
        "Myopic OPF": (MyopicPolicy(), None),
        "Rule-based (FCR-first, SOC 0.55)": (SocRule(lambda e, t: np.full(e.B, 0.55), "fcr"), None),
        "Rule-based (max-reserve, SOC 1.0)": (SocRule(lambda e, t: np.full(e.B, 1.0), "full"), None),
        "Rule-based (seasonal reserve)": (SocRule(lambda e, t: np.where(np.isin(arr["month"][t], [11, 12, 1, 2]), 1.0, 0.55), "season"), None),
        "Rule-based (z-threshold, pi>0.3)": (SocRule(lambda e, t: np.where(pi[t] > 0.3, 1.0, 0.55), "zthr"), None),
    }
    trained = {}
    for f in sorted(glob.glob("runs/main_z-none_s[0-9].pt") + glob.glob("runs/comp_z-dt_central_s[0-9].pt")):
        tag = re.sub(r"_s\d+\.pt$", "", f.split("/")[-1])
        if tag.startswith(("pilot", "smoke")):
            continue
        pol, ck = load_trained(f, arr)
        zkey = None if ck["z"] == "none" else ck["z"]
        trained.setdefault(tag, []).append((f, pol, zkey))
    print({k: len(v) for k, v in trained.items()})
    results = {}
    for per, (y, K, seed) in {"test2019": (2019, KT, 2019), "stress2020": (2020, KS, 2020)}.items():
        s, n = year_slice(d, y)
        mask = drought_days_mask(d, s, n)
        print(per, "drought-day hours:", int(mask.sum()))
        pols = dict(rules)
        for tag, lst in trained.items():
            for f, pol, zkey in lst:
                pols[f.split("/")[-1][:-3]] = (pol, zkey)
        results[per] = evaluate_period(pols, arr, zmap, s, n, K, seed, mask)
        results[per + "_mask_hours"] = int(mask.sum())
    # strip big arrays except ens_t of the first seeds (for plots)
    slim = {}
    for per, res in results.items():
        if not isinstance(res, dict):
            slim[per] = res
            continue
        slim[per] = {name: {k: (v if k not in ("ens_t", "lol_t") else v.astype(np.float32)) for k, v in r.items()}
                     for name, r in res.items()}
    pickle.dump({"results": slim, "trained": {k: [x[0] for x in v] for k, v in trained.items()}},
                open("results/smcs_eval.pkl", "wb"))


if __name__ == "__main__":
    main()
