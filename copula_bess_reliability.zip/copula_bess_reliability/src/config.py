"""Configuration: test feeder, costs, reliability data, dependence-signal and learning settings."""
FEEDER = dict(
    zones=3,
    load_peak=[4.0, 3.5, 2.5],          # MW
    wind=[3.0, 1.0, 3.0],               # MW installed
    pv=[2.0, 5.0, 3.0],                 # MW installed
    bess_p=[1.5, 1.0, 1.5],             # MW
    bess_e=[6.0, 4.0, 6.0],             # MWh
    eta=0.95,                           # one-way efficiency
    soc_min=0.10, soc_max=1.0,
    tr_cap=3.75,                        # MW per substation transformer (2 units)
    export_cap=3.0,                     # MW reverse-flow (voltage-rise) limit at the substation
    line_cap=[9.0, 6.5, 4.5],           # MW, sections L1 (sub->Z1), L2 (Z1->Z2), L3 (Z2->Z3)
    line_len=[2.5, 2.0, 3.0],           # km
)
COST = dict(voll=10000.0, cyc=15.0,      # EUR/MWh unserved, EUR/MWh discharged (cycle ageing)
            fcr=10.0, fcr_tau=2.0)       # FCR capacity price EUR/MW/h; energy reservation (h) per MW offered
REL = dict(                              # failure rate [1/yr], mean repair time [h]
    supply=(0.5, 4.0),                   # 33 kV supply point
    trafo=(0.015, 15.0) ,                # each 33/11 kV transformer
    line_per_km=(0.065, 5.0),
)
SIG = dict(H=24, L=48, q=0.1, q_short=0.2)
