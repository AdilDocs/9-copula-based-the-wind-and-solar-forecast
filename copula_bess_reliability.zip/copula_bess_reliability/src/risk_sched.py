"""Stage 2 (revised): copula-based risk-constrained reserve scheduling.

At every hour t the fitted copula model (Stage 1) generates M joint scenarios of the next-24-h mean wind and
solar capacity factors. Each scenario is expanded into an hourly trajectory, and the battery energy that must
be stored now so that the feeder can ride through the coming 24 h without load shedding is computed by a
backward recursion that accounts for recharging in hours with spare import capacity:

    need_{H+1} = 0,   need_h = max(0, need_{h+1} + d_h / eta - eta * min(g_h, P_ch))

where d_h is the deficit (load - renewables - import capacity) and g_h the spare import capacity.
The required energy is the (1 - alpha) quantile of need_1 over the scenarios, i.e. P(shedding) <= alpha.
The SOC set-point is  tau_t = clip(SOC_min + E_req/E_tot, tau_res, SOC_max), where tau_res = 0.55 is the
set-point that maximises reserve revenue. alpha is the only tuned parameter (on 2018 only).

Usage: python risk_sched.py precompute        # E_req tables for dt and indep copulas
       python risk_sched.py tune              # choose alpha on 2018
       python risk_sched.py evaluate          # 2019 test / 2020 stress, same failure histories as evaluate.py
"""
import sys, pickle, time
import numpy as np
import pandas as pd
from scipy import stats
from stage1 import JointDroughtModel
from config import FEEDER, SIG
from common import load_data, year_slice, run_policy
from env import sample_availability, SMIN, SMAX, ETA
from evaluate import drought_days_mask

ALPHAS = [0.5, 0.3, 0.2, 0.1, 0.05, 0.02, 0.01, 0.005, 0.002, 0.0]
H, M = 24, 500
TAU_RES = 0.55
WCAP, PCAP, LPK = sum(FEEDER["wind"]), sum(FEEDER["pv"]), sum(FEEDER["load_peak"])
CAP = 2 * FEEDER["tr_cap"]
E_TOT, P_TOT = sum(FEEDER["bess_e"]), sum(FEEDER["bess_p"])


def fit_models(d):
    tr = d[d.year <= 2017]
    base = JointDroughtModel(H=H, qd=SIG["q"], L=SIG["L"]).fit_marginals(tr)
    out = {}
    for k in ("indep", "t", "dt"):
        m = JointDroughtModel(H=H, qd=SIG["q"], L=SIG["L"])
        m.__dict__.update(base.__dict__)
        m.fit_copula(tr, k)
        out[k] = m
    clim = tr.groupby(["month", "hour"]).solar.mean().unstack().values  # (12, 24)
    return out, clim


def ereq_table(model, d, clim, seed=17, chunk=200):
    """Returns array (T, len(ALPHAS)) of required stored energy [MWh]."""
    phi, u, v, ok, _, _ = model.residual_pobs(d)
    mu_w, mu_s = phi @ model.bw, phi @ model.bs
    cop = model.cop
    uu, vv = np.where(ok, u, 0.5), np.where(ok, v, 0.5)
    rho = cop._eval(cop.params, uu, vv)[1][:-1] if cop.kind != "indep" else np.zeros(len(d))
    rng = np.random.default_rng(seed)
    z1, z2 = rng.standard_normal(M), rng.standard_normal(M)
    nu = cop.nu
    wmix = np.ones(M) if nu is None else np.sqrt(nu / rng.chisquare(nu, M))
    mon, hr = d["month"].values, d["hour"].values
    wind, load = d["wind"].values, d["load"].values
    T = len(d)
    # calendar of the next H hours and last-week load forecast
    idx = np.clip(np.arange(T)[:, None] + np.arange(1, H + 1)[None], 0, T - 1)
    load_fc = load[np.clip(idx - 168, 0, None)]                        # (T, H) persistence of last week
    sol_shape = clim[mon[idx] - 1, hr[idx]]                             # (T, H)
    sol_shape_mean = sol_shape.mean(1, keepdims=True)
    out = np.zeros((T, len(ALPHAS)), np.float32)
    ew_s, es_s = model.ew_sorted, model.es_sorted
    grid_w = (np.arange(len(ew_s)) + .5) / (len(ew_s) + 1)
    grid_s = (np.arange(len(es_s)) + .5) / (len(es_s) + 1)
    for c0 in range(0, T, chunk):
        sl = slice(c0, min(T, c0 + chunk))
        n = sl.stop - sl.start
        r = rho[sl, None]
        if cop.kind == "indep":
            a1 = np.broadcast_to(stats.norm.cdf(z1), (n, M)); a2 = np.broadcast_to(stats.norm.cdf(z2), (n, M))
        else:
            x1 = z1[None] * wmix[None]
            x2 = (r * z1[None] + np.sqrt(1 - r ** 2) * z2[None]) * wmix[None]
            a1, a2 = stats.t.cdf(x1, nu), stats.t.cdf(x2, nu)
        Yw = mu_w[sl, None] + model.sw * np.interp(a1, grid_w, ew_s)
        Ys = mu_s[sl, None] + model.ss * np.interp(a2, grid_s, es_s)
        mm = np.broadcast_to(mon[sl, None], (n, M)); hh = np.broadcast_to(hr[sl, None], (n, M))
        Wb = model.cW.ppf(stats.norm.cdf(Yw), mm, hh)                  # (n, M) 24-h mean wind CF
        Sb = model.cS.ppf(stats.norm.cdf(Ys), mm, hh)
        # hourly trajectories (n, M, H): wind ramps from current value to a level matching the mean
        w0 = wind[sl, None, None]
        wend = np.clip(2 * Wb[..., None] - w0, 0, 1)
        frac = (np.arange(1, H + 1) / H)[None, None]
        wpath = np.clip(w0 + (wend - w0) * frac, 0, 1)
        spath = sol_shape[sl, None, :] * (Sb[..., None] / np.maximum(sol_shape_mean[sl, None, :], 1e-6))
        R = WCAP * wpath + PCAP * np.clip(spath, 0, 1)
        Dm = LPK * load_fc[sl, None, :]
        net = Dm - R
        deficit = np.maximum(net - CAP, 0)
        head = np.minimum(np.maximum(CAP - net, 0), P_TOT)
        need = np.zeros((n, M))
        for h in range(H - 1, -1, -1):
            need = np.maximum(0, need + deficit[..., h] / ETA - ETA * head[..., h])
        out[sl] = np.quantile(need, [1 - a for a in ALPHAS], axis=1).T
    return out


class RiskPolicy:
    def __init__(self, ereq_col, name):
        self.e, self.name = ereq_col, name

    def act(self, env):
        t = env.t0 + env.k
        tau = np.clip(SMIN + self.e[t] / env.be.sum(), TAU_RES, SMAX)
        a = 2 * (tau - SMIN) / (SMAX - SMIN) - 1
        return env.soc_target_to_power(np.broadcast_to(a[:, None], (env.B, 3)).copy())


def main(cmd):
    d, arr = load_data()
    if cmd == "precompute":
        t0 = time.time()
        models, clim = fit_models(d)
        tabs = {k: ereq_table(m, d, clim) for k, m in models.items()}
        pickle.dump(tabs, open("results/risk_ereq.pkl", "wb"))
        for k, v in tabs.items():
            print(k, "mean E_req by alpha", dict(zip(ALPHAS, v.mean(0).round(2))), round(time.time() - t0))
        return
    tabs = pickle.load(open("results/risk_ereq.pkl", "rb"))
    if cmd == "tune":
        s, n = year_slice(d, 2018)
        av = sample_availability(32, n, np.random.default_rng(1234), 1.0)
        rows = []
        for k, tab in tabs.items():
            for j, a in enumerate(ALPHAS):
                r = run_policy(RiskPolicy(tab[:, j], k), arr, None, s, n, 32, np.random.default_rng(0),
                               use_z=False, avail=av)
                rows.append(dict(copula=k, alpha=a, **{m: float(np.mean(r[m])) for m in ["LOLE", "EENS", "FCR", "TC"]}))
                print(rows[-1], flush=True)
        pd.DataFrame(rows).to_csv("results/risk_tuning_2018.csv", index=False)
        return
    if cmd == "evaluate":
        tune = pd.read_csv("results/risk_tuning_2018.csv")
        out = {}
        for per, (y, K, seed) in {"test2019": (2019, 300, 2019), "stress2020": (2020, 200, 2020)}.items():
            s, n = year_slice(d, y)
            mask = drought_days_mask(d, s, n)
            av = sample_availability(K, n, np.random.default_rng(seed), 1.0)
            out[per] = {}
            for k, tab in tabs.items():
                best = tune[tune.copula == k].sort_values("TC").iloc[0]
                j = ALPHAS.index(best.alpha)
                r = run_policy(RiskPolicy(tab[:, j], k), arr, None, s, n, K, np.random.default_rng(0),
                               use_z=False, avail=av)
                r["EENS_drought"] = r["ens_t"][mask].sum() * 8760.0 / n
                r["alpha"] = best.alpha
                out[per][f"risk_{k}"] = r
                print(per, k, "alpha", best.alpha,
                      {m: round(float(np.mean(r[m])), 2) for m in ["LOLP", "LOLE", "EENS", "EENS_drought", "FCR", "TC"]},
                      flush=True)
        pickle.dump(out, open("results/smcs_risk.pkl", "wb"))


if __name__ == "__main__":
    main(sys.argv[1])
