"""Data preparation: OPSD 60-min single-index -> clean hourly DE wind/solar CF and load.

Usage: python data_prep.py <path_to_time_series_60min_singleindex.csv>
Output: data/de_hourly.pkl  (index: UTC hourly timestamps 2015-01-01 .. 2020-09-30)
"""
import sys
import numpy as np
import pandas as pd

SRC = sys.argv[1] if len(sys.argv) > 1 else "data/time_series_60min_singleindex.csv"
COLS = ["utc_timestamp", "DE_load_actual_entsoe_transparency", "DE_solar_profile", "DE_wind_profile",
        "DE_solar_capacity", "DE_wind_capacity", "DE_solar_generation_actual", "DE_wind_generation_actual"]

d = pd.read_csv(SRC, usecols=COLS, parse_dates=["utc_timestamp"]).set_index("utc_timestamp")
d = d.loc["2015-01-01":"2020-09-30 23:00"]
d = d.asfreq("h")

# 2020: OPSD profiles are not provided -> CF = generation / last reported 2019 capacity
cap_w = d["DE_wind_capacity"].loc["2019"].dropna().iloc[-1]
cap_s = d["DE_solar_capacity"].loc["2019"].dropna().iloc[-1]
m20 = d.index.year == 2020
d.loc[m20, "DE_wind_profile"] = d.loc[m20, "DE_wind_generation_actual"] / cap_w
d.loc[m20, "DE_solar_profile"] = d.loc[m20, "DE_solar_generation_actual"] / cap_s

out = pd.DataFrame(index=d.index)
out["wind"] = d["DE_wind_profile"]
out["solar"] = d["DE_solar_profile"]
out["load"] = d["DE_load_actual_entsoe_transparency"]

report = {"missing_before": out.isna().sum().to_dict()}
# gaps: linear interpolation up to 6 h, longer gaps filled by same hour of previous day
out = out.interpolate(limit=6, limit_area="inside")
for c in out:
    for _ in range(7):
        miss = out[c].isna()
        if not miss.any():
            break
        out.loc[miss, c] = out[c].shift(24)[miss]
out = out.bfill().ffill()
report["missing_after"] = out.isna().sum().to_dict()

out["wind"] = out["wind"].clip(0, 1)
out["solar"] = out["solar"].clip(0, 1)
out.loc[out["solar"] < 1e-3, "solar"] = 0.0
# load normalised by the maximum of the training years (2015-2017)
out["load"] = out["load"] / out.loc["2015":"2017", "load"].max()

loc = out.index.tz_convert("Europe/Berlin")
out["hour"] = loc.hour
out["month"] = loc.month
out["dow"] = loc.dayofweek
out["doy"] = loc.dayofyear
out["year"] = out.index.year

out.to_pickle("data/de_hourly.pkl")
print(report)
print(out.groupby("year")[["wind", "solar", "load"]].agg(["mean", "max"]).round(3))
