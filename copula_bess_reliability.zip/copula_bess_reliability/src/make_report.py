"""Builds Tables 1-6 (CSV + LaTeX) and Figures 2-4 (PNG + PDF) from the experiment outputs."""
import glob, json, pickle, re
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from scipy import stats
from config import FEEDER, COST, REL, SIG

C = ["#2a78d6", "#eb6834", "#1baf7a", "#eda100", "#e87ba4", "#6250d6"]
plt.rcParams.update({"font.size": 9, "axes.spines.top": False, "axes.spines.right": False,
                     "axes.grid": True, "grid.color": "#e6e5e0", "grid.linewidth": 0.6, "lines.linewidth": 1.6,
                     "axes.edgecolor": "#8a8984", "figure.dpi": 150, "savefig.bbox": "tight"})
METRICS = ["LOLP", "LOLE", "EENS", "EENS_drought", "FCR", "OPC", "TC"]


def save_tab(df, name, caption):
    df.to_csv(f"results/{name}.csv", index=False)
    with open(f"results/{name}.tex", "w") as f:
        f.write(df.to_latex(index=False, escape=True, caption=caption, label=f"tab:{name}", float_format="%.2f"))


# ------------------------------------------------------------------------------------------ Table 1, 2
def tables_setup():
    rows = [("Zones / BESS agents", "3 (radial chain Supply-T1||T2-L1-Z1-L2-Z2-L3-Z3)"),
            ("Peak load per zone [MW]", ", ".join(map(str, FEEDER["load_peak"]))),
            ("Wind capacity per zone [MW]", ", ".join(map(str, FEEDER["wind"]))),
            ("PV capacity per zone [MW]", ", ".join(map(str, FEEDER["pv"]))),
            ("BESS power / energy per zone [MW / MWh]", ", ".join(f"{p}/{e}" for p, e in zip(FEEDER["bess_p"], FEEDER["bess_e"]))),
            ("BESS efficiency (one-way), SOC limits", f"{FEEDER['eta']}, [{FEEDER['soc_min']}, {FEEDER['soc_max']}]"),
            ("Substation transformers", f"2 x {FEEDER['tr_cap']} MW; export (reverse-flow) limit {FEEDER['export_cap']} MW"),
            ("Line section capacities [MW] / lengths [km]", f"{FEEDER['line_cap']} / {FEEDER['line_len']}"),
            ("Supply point failure rate / MTTR", f"{REL['supply'][0]} /yr, {REL['supply'][1]} h"),
            ("Transformer failure rate / MTTR", f"{REL['trafo'][0]} /yr, {REL['trafo'][1]} h"),
            ("Line failure rate / MTTR", f"{REL['line_per_km'][0]} /(km yr), {REL['line_per_km'][1]} h"),
            ("VOLL / cycle-ageing cost", f"{COST['voll']:.0f} EUR/MWh / {COST['cyc']} EUR/MWh"),
            ("Balancing capacity price / energy reservation", f"{COST['fcr']} EUR/MW/h, {COST['fcr_tau']} h each direction"),
            ("Energy price", "residual-load price proxy calibrated on 2019 DE-LU day-ahead (R2 0.73; 0.68 in 2020)"),
            ("Data", "OPSD time_series_60min_singleindex, DE wind/solar profiles + load, hourly"),
            ("Split", "train 2015-2017, validation 2018, test 2019, stress Jan-Sep 2020 (COVID load)"),
            ("Preprocessing", "gaps <=6 h interpolated, longer from previous day; CF clipped [0,1]; 2020 CF = gen/2019 capacity; load / 2015-17 max")]
    save_tab(pd.DataFrame(rows, columns=["Item", "Value"]), "table1_system_data", "Test system and data settings")
    rows = [("Signal horizon H / drought quantile", f"{SIG['H']} h / q={SIG['q_short']} (combined RE shortfall)"),
            ("Copula estimation", "pseudo-ML on forecast-error pseudo-observations (IFM); Nelder-Mead, multi-start"),
            ("Dynamic recursion lag window L / offset", f"{SIG['L']} h / H (only realised errors)"),
            ("Monte-Carlo draws for pi_t", "1000 (common random numbers)"),
            ("MAPPO actor / critic", "shared actor 2x128 tanh + agent one-hot; centralised critic 2x256 tanh"),
            ("Action", "SOC set-point in [0.1, 1.0]; emergency support + feasibility projection"),
            ("Learning rate / epochs / minibatch", "5e-4 (actor), 1e-3 (critic) / 5 / 2048"),
            ("gamma / GAE lambda / clip", "0.995 / 0.95 / 0.2"),
            ("Parallel episodes x length / updates", "128 x 168 h / 250 (best on 2018 validation)"),
            ("Reward", "-(controllable cost)/1000, running return normalisation"),
            ("Training failures", "none (failure-free training); evaluation with full failure model"),
            ("Seeds", "5 (main), 3 (ablation, comparison)"),
            ("SMCS", "K sampled years with common random numbers; CoV(EENS) reported"),
            ("Software / hardware", "Python 3.13, NumPy, SciPy, PyTorch 2.x (CPU), 2 vCPU")]
    save_tab(pd.DataFrame(rows, columns=["Parameter", "Setting"]), "table2_hyperparameters",
             "Hyper-parameters and simulation settings")


# ------------------------------------------------------------------------------------------ Table 3
def table3():
    t = pd.read_csv("results/table3_copula_fit.csv")
    try:
        sc = pd.read_csv("results/table_scenario_models.csv")
        m = dict(zip(sc.model, sc.joint_drought_freq))
        t["JointDroughtDays_synthetic"] = t.Model.map(m)
        t["JointDroughtDays_history"] = sc.joint_drought_freq.iloc[0]
        ecol = [c for c in sc.columns if c.startswith("EENS_Rule")]
        if ecol:
            t["EENS_noFail_synthetic"] = t.Model.map(dict(zip(sc.model, sc[ecol[0]])))
            t["EENS_noFail_history"] = sc[ecol[0]].iloc[0]
    except FileNotFoundError:
        pass
    cols = [c for c in ["Model", "k", "LL_train", "AIC", "BIC", "LL_test", "lamL_model", "lamL_emp_test", "mean_pi_test",
                        "realised_freq_test", "Brier_test", "BSS_test", "JointDroughtDays_synthetic",
                        "JointDroughtDays_history", "EENS_noFail_synthetic", "EENS_noFail_history", "params"] if c in t]
    save_tab(t[cols], "table3_dependence_models", "Dependence-model comparison")


# ------------------------------------------------------------------------------------------ Tables 4-6
def label(name):
    m = re.match(r"(\w+)_z-(\w+?)(_central)?(_hist)?_s(\d)", name)
    if not m:
        return name, None
    tag, z, cen, hist, seed = m.groups()
    return (tag, z, bool(cen), bool(hist)), int(seed)


def agg(res):
    """group seeds -> mean, std over seeds of K-averages; also per-sample seed-averaged arrays."""
    groups = {}
    for name, r in res.items():
        key, seed = label(name)
        groups.setdefault(key, []).append(r)
    out = {}
    for key, lst in groups.items():
        row = {}
        for m in METRICS:
            vals = [float(np.mean(r[m])) for r in lst]
            row[m] = np.mean(vals)
            row[m + "_sd"] = np.std(vals) if len(vals) > 1 else 0.0
        row["n_seeds"] = len(lst)
        row["TC_samples"] = np.mean([r["TC"] for r in lst], 0)
        row["EENS_samples"] = np.mean([r["EENS"] for r in lst], 0)
        out[key] = row
    return out


def fmt(row, m, d=2):
    if row["n_seeds"] > 1:
        return f"{row[m]:.{d}f} ± {row[m + '_sd']:.{d}f}"
    return f"{row[m]:.{d}f}"


def tables_results():
    R = pickle.load(open("results/smcs_eval.pkl", "rb"))["results"]
    A = {p: agg(R[p]) for p in ("test2019", "stress2020")}
    names = {"Myopic OPF": "Myopic OPF (min-curtailment)",
             "Rule-based (FCR-first, SOC 0.55)": "Rule-based: FCR-first (SOC 0.55)",
             "Rule-based (max-reserve, SOC 1.0)": "Rule-based: max-reserve (SOC 1.0)",
             "Rule-based (seasonal reserve)": "Rule-based: seasonal reserve",
             ("main", "none", False, False): "Proposed: MADRL (multi-service BESS)",
             ("main", "dt", False, False): "Proposed + copula signal z_t in observations"}
    prop = A["test2019"][("main", "none", False, False)]
    rows = []
    for k, nm in names.items():
        r19, r20 = A["test2019"][k], A["stress2020"][k]
        rows.append({"Policy": nm, "LOLP (x1e-3)": fmt({**r19, "LOLP": r19["LOLP"] * 1e3, "LOLP_sd": r19["LOLP_sd"] * 1e3, "n_seeds": r19["n_seeds"]}, "LOLP"),
                     "LOLE [h/yr]": fmt(r19, "LOLE"), "EENS [MWh/yr]": fmt(r19, "EENS"),
                     "EENS drought days": fmt(r19, "EENS_drought"),
                     "Balancing revenue [kEUR/yr]": fmt(r19, "FCR", 1), "Total cost [kEUR/yr]": fmt(r19, "TC", 1),
                     "TC change vs proposed [%]": f"{100 * (r19['TC'] - prop['TC']) / prop['TC']:+.1f}",
                     "Stress 2020 EENS": fmt(r20, "EENS"), "Stress 2020 TC": fmt(r20, "TC", 1)})
    # paired Wilcoxon over SMCS samples: proposed vs each
    p = []
    for k in names:
        if k == ("main", "none", False, False):
            p.append("-")
            continue
        a, b = A["test2019"][k]["TC_samples"], prop["TC_samples"]
        try:
            p.append(f"{stats.wilcoxon(a, b).pvalue:.1e}")
        except ValueError:
            p.append("n/a")
    df = pd.DataFrame(rows)
    df["Wilcoxon p (TC vs proposed)"] = p
    save_tab(df, "table4_main_results", "Reliability and cost on the 2019 test year and the 2020 stress period (TC change relative to the proposed MADRL)")
    # Table 5 ablation: z source
    abl = [("Proposed MADRL (no signal in observations)", ("main", "none", False, False))]
    for z, nm in [("indep", "Independent"), ("gauss", "Static Gaussian"), ("t", "Static t"),
                  ("dgauss", "Dynamic Gaussian")]:
        abl.append((f"MADRL + z_t ({nm} copula)", ("abl", z, False, False)))
    abl.append(("MADRL + z_t (Dynamic t copula)", ("main", "dt", False, False)))
    rows = []
    for nm, k in abl:
        if k not in A["test2019"]:
            continue
        r = A["test2019"][k]
        rows.append({"Variant": nm, "seeds": r["n_seeds"], "LOLE [h/yr]": fmt(r, "LOLE"), "EENS [MWh/yr]": fmt(r, "EENS"),
                     "EENS drought days": fmt(r, "EENS_drought"), "Balancing revenue": fmt(r, "FCR", 1),
                     "Total cost": fmt(r, "TC", 1), "Stress 2020 TC": fmt(A["stress2020"][k], "TC", 1)})
    save_tab(pd.DataFrame(rows), "table5_ablation", "Ablation: source of the dependence signal")
    # Table 6 comparative
    comp = [("Li et al. [9th-ref2]: dynamic copula + SMCS, restoration without storage scheduling", "Myopic OPF"),
            ("Carvalho et al. [9th-ref4]: static copula, non-sequential MCS (static SOC policy)", "Rule-based (FCR-first, SOC 0.55)"),
            ("Single-agent (centralised) PPO with z_t", ("comp", "dt", True, False)),
            ("Wu et al. [9th-ref18]-style MADRL with 24-h history features, no z_t", ("comp", "none", False, True)),
            ("Proposed: dynamic-copula risk model + MADRL + SMCS", ("main", "none", False, False))]
    rows = []
    for nm, k in comp:
        if k not in A["test2019"]:
            continue
        r = A["test2019"][k]
        rows.append({"Method": nm, "LOLE [h/yr]": fmt(r, "LOLE"), "EENS [MWh/yr]": fmt(r, "EENS"),
                     "Balancing revenue": fmt(r, "FCR", 1), "Total cost": fmt(r, "TC", 1),
                     "EENS change vs Li et al. [%]": f"{100 * (r['EENS'] - A['test2019']['Myopic OPF']['EENS']) / A['test2019']['Myopic OPF']['EENS']:+.1f}"})
    rt = json.load(open("results/runtime.json")) if glob.glob("results/runtime.json") else {}
    df = pd.DataFrame(rows)
    save_tab(df, "table6_comparative", "Comparison with representative methods (re-implemented on the same system, data and failure histories)")
    return A


# ------------------------------------------------------------------------------------------ Figures
def fig2():
    SS = pickle.load(open("results/signals_pi_M8000.pkl", "rb"))["signals"]; S = SS["t"]
    tr = pickle.load(open("results/fig2_traj_risk.pkl", "rb"))
    fig, ax = plt.subplots(2, 1, figsize=(7.2, 5.4), sharex=True)
    fig.subplots_adjust(hspace=0.55)
    w = S.loc[tr["start"]:tr["end"]]
    real = w.real.fillna(0).values > 0.5
    x = w.index.tz_convert("Europe/Berlin").tz_localize(None)
    ax[0].fill_between(x, 0, 1, where=real, color="#d9d8d3", step="post", label="realised 24-h shortfall ahead")
    ax[0].plot(x, w.pi.values, color=C[0], label=r"$\pi_t$ (Student-$t$ copula)")
    ax[0].plot(x, SS["indep"].loc[tr["start"]:tr["end"]].pi.values, color=C[1], lw=1.2, label=r"$\pi_t$ (independence)")
    ax[0].set_ylabel("Probability")
    ax[0].set_ylim(0, 1.0)
    ax[0].legend(loc="lower left", bbox_to_anchor=(0, 1.01), fontsize=7, frameon=False, ncol=3, borderaxespad=0)
    ax[0].set_title("(a) Joint wind-solar shortfall probability", loc="left", fontsize=9, pad=20)
    ax[1].plot(x, tr["soc_z"], color=C[4], label="Proposed risk-constrained scheduler")
    ax[1].plot(x, tr["soc_noz"], color=C[3], label="MAPPO")
    ax[1].plot(x, tr["soc_fcr"], color=C[2], lw=1.0, ls="--", label="FCR-first rule")
    ax[1].set_ylabel("Mean BESS SOC")
    ax[1].set_ylim(0, 1.05)
    ax[1].legend(loc="lower left", bbox_to_anchor=(0, 1.01), fontsize=7, frameon=False, ncol=3, borderaxespad=0)
    ax[1].set_title("(b) Battery state of charge (2019 test data)", loc="left", fontsize=9, pad=20)
    fig.autofmt_xdate()
    fig.savefig("figures/fig2_mechanism.png", dpi=300)
    fig.savefig("figures/fig2_mechanism.pdf")


def fig3(A):
    fig, ax = plt.subplots(1, 2, figsize=(7.2, 2.8))
    for z, col, nm in (("dt", C[4], "+ $z_t$ (ablation)"), ("none", C[3], "(proposed)")):
        logs = [json.load(open(f)) for f in sorted(glob.glob(f"runs/main_z-{z}_s[0-9]_log.json"))]
        ev = [[r for r in l if "TC" in r] for l in logs]
        n = min(len(e) for e in ev)
        st = np.array([r["steps"] for r in ev[0][:n]]) / 1e6
        tc = np.array([[r["TC"] for r in e[:n]] for e in ev])
        m, s = tc.mean(0), tc.std(0)
        ax[0].plot(st, m, color=col, label=f"MADRL {nm}")
        ax[0].fill_between(st, m - s, m + s, color=col, alpha=0.18, lw=0)
    ax[0].set_xlabel("Training transitions [million]")
    ax[0].set_ylabel("Validation total cost [kEUR/yr]")
    ax[0].legend(frameon=False, fontsize=7)
    ax[0].set_title("(a) MAPPO training (mean ± std, 5 seeds)", loc="left", fontsize=9)
    R = pickle.load(open("results/smcs_eval.pkl", "rb"))["results"]["test2019"]
    e = R["main_z-none_s0"]["EENS"]
    n = np.arange(1, len(e) + 1)
    m = np.cumsum(e) / n
    sd = np.array([np.std(e[:k], ddof=1) if k > 1 else np.nan for k in n])
    cov = sd / np.sqrt(n) / m
    ax[1].plot(n, m, color=C[0], label="EENS running mean")
    ax[1].set_xlabel("Simulated years")
    ax[1].set_ylabel("EENS [MWh/yr]")
    ax2 = ax[1].inset_axes([0.45, 0.45, 0.5, 0.45])
    ax2.plot(n, cov * 100, color=C[1])
    ax2.axhline(5, color="#8a8984", lw=0.8, ls="--")
    ax2.set_ylabel("CoV [%]", fontsize=7)
    ax2.tick_params(labelsize=6)
    ax2.set_ylim(0, 20)
    ax[1].set_title("(b) SMCS convergence (proposed, 2019)", loc="left", fontsize=9)
    fig.tight_layout()
    fig.savefig("figures/fig3_convergence.png")
    fig.savefig("figures/fig3_convergence.pdf")
    return float(cov[-1])


def fig4():
    S = pickle.load(open("results/sensitivity.pkl", "rb"))
    S.update(pickle.load(open("results/sensitivity_risk.pkl", "rb")))
    pars = [("re", "Renewable capacity scale"), ("bess", "BESS size scale"), ("fail", "Failure-rate multiplier"),
            ("load", "Load scale")]
    pols = [("Myopic OPF", "Myopic OPF", C[0], "o"), ("Rule-based (FCR-first)", "FCR-first", C[2], "s"),
            ("Rule-based (max-reserve)", "Max-reserve", C[1], "^"), ("Seasonal", "Seasonal reserve", C[5], "v"),
            ("main_z-none", "MAPPO", C[3], "D"), ("Proposed", "Proposed", C[4], "o")]
    fig, axs = plt.subplots(1, 4, figsize=(7.4, 2.6))
    for ax, (p, t) in zip(axs, pars):
        vals = sorted({k[1] for k in S if k[0] == p})
        for key, nm, col, mk in pols:
            y = []
            for v in vals:
                ks = [k for k in S if k[0] == p and k[1] == v and k[2].startswith(key)]
                y.append(np.mean([S[k]["TC"] for k in ks]))
            lw = 2.2 if nm == "Proposed" else 1.2
            ax.plot(vals, y, marker=mk, ms=4, lw=lw, color=col, label=nm, zorder=3 if nm == "Proposed" else 2)
        ax.set_xlabel(t, fontsize=8)
        ax.tick_params(labelsize=7)
        ax.set_xticks(vals)
    axs[0].set_ylabel("Total cost [kEUR/yr]")
    h, l = axs[0].get_legend_handles_labels()
    fig.legend(h, l, loc="lower center", bbox_to_anchor=(0.5, 1.0), ncol=6, fontsize=7, frameon=False)
    fig.tight_layout()
    fig.savefig("figures/fig4_sensitivity.png", dpi=300, bbox_inches="tight")
    fig.savefig("figures/fig4_sensitivity.pdf", bbox_inches="tight")


if __name__ == "__main__":
    # System/setting tables and the dependence-model table; the remaining result tables of the paper are built
    # by make_tables.py, and Fig. 3 (SMCS convergence) by fig3_conv.py.
    tables_setup()
    table3()
    try:
        fig2()
    except FileNotFoundError as e:
        print("fig2 skipped", e)
    try:
        fig4()
    except FileNotFoundError as e:
        print("fig4 skipped", e)
