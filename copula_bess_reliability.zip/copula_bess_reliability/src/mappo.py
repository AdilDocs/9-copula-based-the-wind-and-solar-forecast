"""Stage 2: MAPPO (centralised training, decentralised execution) for the BESS agents.

Variants
  --z none|indep|gauss|t|dgauss|dt     dependence signal z_t from Stage 1 (none = no signal)
  --central                            single centralised agent (one policy acting on all BESS)
  --hist                               add 24-h history of local features to the observation
                                       (temporal feature extraction in the spirit of Wu et al.)
Usage: python mappo.py --z dt --seed 0 --updates 300 --tag main
"""
import argparse, time, json, os
import numpy as np
import torch
import torch.nn as nn
from common import load_data, load_z, year_slice, run_policy
from env import FeederEnv, Z, sample_availability

torch.set_num_threads(1)


class HistWrap:
    """Appends the last 24 h of (net load, wind, solar, price) of the agent's zone to the observation."""
    def __init__(self, arr, lpk, wcap, pcap, n=24):
        self.arr, self.n = arr, n
        self.lpk, self.wcap, self.pcap = lpk, wcap, pcap

    def feats(self, t):  # t: (B,)
        idx = np.clip(t[:, None] - np.arange(1, self.n + 1)[None], 0, None)
        L = self.arr["load"][idx]
        W = self.arr["wind"][idx]
        S = self.arr["solar"][idx]
        p = (self.arr["price"][idx] - 40) / 15
        net = (L[:, None] * self.lpk[None, :, None] - W[:, None] * self.wcap[None, :, None]
               - S[:, None] * self.pcap[None, :, None]) / self.lpk[None, :, None]
        out = np.concatenate([net, np.repeat(W[:, None], Z, 1), np.repeat(S[:, None], Z, 1),
                              np.repeat(p[:, None], Z, 1)], -1)
        return out  # (B, Z, 4n)


def mlp(i, o, h=128):
    return nn.Sequential(nn.Linear(i, h), nn.Tanh(), nn.Linear(h, h), nn.Tanh(), nn.Linear(h, o))


class Agent(nn.Module):
    def __init__(self, obs_dim, central=False, ippo=False):
        super().__init__()
        self.central = central
        self.ippo = ippo
        if central:
            self.pi = mlp(obs_dim * Z, Z, 256)
        else:
            self.pi = mlp(obs_dim + Z, 1, 128)
        self.logstd = nn.Parameter(torch.full((Z,) if central else (1,), -1.2))
        with torch.no_grad():   # start near SOC set-point ~0.7
            self.pi[-1].weight.mul_(0.1)
            self.pi[-1].bias.fill_(0.3)
        self.v = mlp(obs_dim + Z, 1, 128) if ippo else mlp(obs_dim * Z, 1, 256)
        self.eye = torch.eye(Z)

    def _actor_in(self, o):  # o: (N, Z, D)
        if self.central:
            return o.reshape(o.shape[0], -1)
        ids = self.eye.expand(o.shape[0], Z, Z)
        return torch.cat([o, ids], -1)

    def dist(self, o):
        mu = self.pi(self._actor_in(o))
        if not self.central:
            mu = mu.squeeze(-1)
        std = self.logstd.exp().expand_as(mu)
        return torch.distributions.Normal(mu, std)

    def value(self, o):
        if self.ippo:   # independent (local) critic per agent -> (N, Z)
            return self.v(self._actor_in(o)).squeeze(-1)
        return self.v(o.reshape(o.shape[0], -1)).squeeze(-1)


class TorchPolicy:
    """Deterministic execution wrapper used by the SMCS evaluator."""
    def __init__(self, agent, hist=None, norm=None):
        self.agent, self.hist, self.norm = agent, hist, norm

    def obs(self, env, o):
        if self.hist is not None:
            t = env.t0 + env.k
            o = np.concatenate([o, self.hist.feats(t)], -1)
        return o

    def act(self, env):
        o = self.obs(env, env._obs())
        with torch.no_grad():
            mu = self.agent.dist(torch.as_tensor(o, dtype=torch.float32)).mean
        return env.soc_target_to_power(np.clip(mu.numpy(), -1, 1))


def train(args):
    rng = np.random.default_rng(args.seed)
    torch.manual_seed(args.seed)
    d, arr = load_data()
    z = None if args.z == "none" else load_z(args.z, d)
    use_z = z is not None
    s_tr, n_tr = year_slice(d, 2015, 2017)
    s_va, n_va = year_slice(d, 2018)
    # training env over 2015-2017 only
    tr_arr = {k: v[s_tr:s_tr + n_tr] for k, v in arr.items()}
    tr_z = None if z is None else z[s_tr:s_tr + n_tr]
    env = FeederEnv(tr_arr, tr_z, B=args.B, ep_len=args.ep, rng=rng, rate_mult=args.rate_mult, use_z=use_z)
    env.soc_mode = True
    hist = HistWrap(tr_arr, env.lpk, env.wcap, env.pcap) if args.hist else None
    hist_full = HistWrap(arr, env.lpk, env.wcap, env.pcap) if args.hist else None
    D = env.obs_dim + (96 if args.hist else 0)
    ag = Agent(D, central=args.central, ippo=args.ippo)
    agsum = (lambda x: x) if args.ippo else (lambda x: x.sum(-1))
    opt_pi = torch.optim.Adam(list(ag.pi.parameters()) + [ag.logstd], lr=args.lr)
    opt_v = torch.optim.Adam(ag.v.parameters(), lr=1e-3)
    # fixed validation failure histories (2018)
    vrng = np.random.default_rng(1234)
    vav = sample_availability(args.Kval, n_va, vrng, 1.0)
    log = []
    best = (np.inf, None)
    ret_rms = [0.0, 1e-4, 1.0]   # running mean/var/count of discounted returns (reward scaling)
    disc_ret = np.zeros(args.B)
    tstart = time.time()
    for upd in range(args.updates):
        o = env.reset()
        disc_ret[:] = 0.0
        if hist:
            o = np.concatenate([o, hist.feats(env.t0 + env.k)], -1)
        O, A, LP, R, V = [], [], [], [], []
        done = False
        while not done:
            ot = torch.as_tensor(o, dtype=torch.float32)
            with torch.no_grad():
                dist = ag.dist(ot)
                a = dist.sample()
                lp = agsum(dist.log_prob(a))
                v = ag.value(ot)
            o2, r, done, info = env.step(a.numpy())
            if args.rnorm:
                disc_ret = disc_ret * args.gamma + r
                bm, bv, bc = disc_ret.mean(), disc_ret.var(), len(disc_ret)
                m0, v0, c0 = ret_rms
                tot = c0 + bc
                dm = bm - m0
                ret_rms = [m0 + dm * bc / tot, (v0 * c0 + bv * bc + dm ** 2 * c0 * bc / tot) / tot, tot]
                r = r / np.sqrt(ret_rms[1] + 1e-8)
            O.append(ot); A.append(a); LP.append(lp); R.append(torch.as_tensor(r, dtype=torch.float32)); V.append(v)
            if o2 is not None and hist:
                o2 = np.concatenate([o2, hist.feats(env.t0 + env.k)], -1)
            o = o2
        with torch.no_grad():
            vlast = ag.value(torch.as_tensor(o, dtype=torch.float32))
        T = len(R)
        shp = (args.B, Z) if args.ippo else (args.B,)
        adv = torch.zeros((T,) + shp)
        gae = torch.zeros(shp)
        for t in reversed(range(T)):
            vn = vlast if t == T - 1 else V[t + 1]
            rt = R[t][:, None] if args.ippo else R[t]
            delta = rt + args.gamma * vn - V[t]
            gae = delta + args.gamma * args.lam * gae
            adv[t] = gae
        ret = adv + torch.stack(V)
        O = torch.stack(O).reshape(T * args.B, Z, D)
        A = torch.stack(A).reshape(T * args.B, -1)
        LP = torch.stack(LP).reshape((T * args.B,) + shp[1:])
        adv = adv.reshape((T * args.B,) + shp[1:])
        ret = ret.reshape((T * args.B,) + shp[1:])
        adv_n = (adv - adv.mean()) / (adv.std() + 1e-8)
        N = O.shape[0]
        for ep in range(args.epochs):
            perm = torch.randperm(N)
            for i in range(0, N, args.mb):
                b = perm[i:i + args.mb]
                dist = ag.dist(O[b])
                lp = agsum(dist.log_prob(A[b]))
                ratio = (lp - LP[b]).exp()
                s1 = ratio * adv_n[b]
                s2 = ratio.clamp(1 - args.clip, 1 + args.clip) * adv_n[b]
                loss_pi = -torch.min(s1, s2).mean() - args.ent * dist.entropy().sum(-1).mean()
                opt_pi.zero_grad(); loss_pi.backward()
                nn.utils.clip_grad_norm_(list(ag.pi.parameters()) + [ag.logstd], 0.5); opt_pi.step()
                loss_v = ((ag.value(O[b]) - ret[b]) ** 2).mean()
                opt_v.zero_grad(); loss_v.backward(); nn.utils.clip_grad_norm_(ag.v.parameters(), 0.5); opt_v.step()
        rec = dict(update=upd, steps=(upd + 1) * T * args.B, ep_return=float(torch.stack(R).sum(0).mean()),
                   std=float(ag.logstd.exp().mean()), time=time.time() - tstart)
        if (upd + 1) % args.eval_every == 0 or upd == args.updates - 1:
            pol = TorchPolicy(ag, hist_full)
            res = run_policy(pol, arr, z, s_va, n_va, args.Kval, np.random.default_rng(0), use_z=use_z, avail=vav)
            rec.update({k: float(np.mean(v)) for k, v in res.items()})
            if rec["TC"] < best[0]:
                best = (rec["TC"], {k: v.clone() for k, v in ag.state_dict().items()})
            print(json.dumps({k: (round(v, 3) if isinstance(v, float) else v) for k, v in rec.items()}), flush=True)
        log.append(rec)
    os.makedirs("runs", exist_ok=True)
    name = f"runs/{args.tag}_z-{args.z}{'_central' if args.central else ''}{'_hist' if args.hist else ''}{'_ippo' if args.ippo else ''}_s{args.seed}"
    torch.save({"state": best[1], "D": D, "central": args.central, "hist": args.hist, "z": args.z, "ippo": args.ippo,
                "best_val_TC": best[0]}, name + ".pt")
    json.dump(log, open(name + "_log.json", "w"))
    return name


if __name__ == "__main__":
    p = argparse.ArgumentParser()
    p.add_argument("--z", default="dt")
    p.add_argument("--seed", type=int, default=0)
    p.add_argument("--updates", type=int, default=300)
    p.add_argument("--B", type=int, default=64)
    p.add_argument("--ep", type=int, default=168)
    p.add_argument("--lr", type=float, default=3e-4)
    p.add_argument("--gamma", type=float, default=0.99)
    p.add_argument("--lam", type=float, default=0.95)
    p.add_argument("--clip", type=float, default=0.2)
    p.add_argument("--ent", type=float, default=0.0)
    p.add_argument("--epochs", type=int, default=5)
    p.add_argument("--mb", type=int, default=2048)
    p.add_argument("--rate_mult", type=float, default=2.0)
    p.add_argument("--Kval", type=int, default=32)
    p.add_argument("--eval_every", type=int, default=10)
    p.add_argument("--central", action="store_true")
    p.add_argument("--hist", action="store_true")
    p.add_argument("--ippo", action="store_true")
    p.add_argument("--tag", default="main")
    p.add_argument("--rnorm", type=int, default=1)
    print(train(p.parse_args()))
