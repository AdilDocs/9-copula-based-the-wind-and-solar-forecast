"""Alternative Stage 1: conformal quantile forecasting of the required battery reserve.

Target  : E*_t = energy that must be stored at hour t so that the feeder rides through hours t+1..t+24
          without load shedding (hindsight recursion on the realised load / wind / solar, N-0 capacity):
              need_{H+1}=0,  need_h = max(0, need_{h+1} + d_h/eta - eta*min(g_h, P_ch))
Model   : gradient-boosted quantile regression  q_hat_beta(x_t)  (features available at time t only)
Conformal calibration (2018): delta = (1-alpha)(1+1/n) empirical quantile of (E* - q_hat) on 2018,
          E_req,t = max(0, q_hat_beta(x_t) + delta)  ->  P(E* > E_req) <= alpha (marginal, exchangeable)
Policy  : tau_t = clip(SOC_min + E_req,t / E_tot, 0.55, 1.0)  (same set-point mapping as risk_sched.py)

Usage: python conformal_sched.py fit | tune | evaluate
"""
import sys, pickle, time
import numpy as np
import pandas as pd
from sklearn.ensemble import HistGradientBoostingRegressor
from config import FEEDER
from common import load_data, year_slice, run_policy
from env import sample_availability, SMIN, SMAX, ETA
from evaluate import drought_days_mask
from risk_sched import RiskPolicy

H = 24
WCAP, PCAP, LPK = sum(FEEDER["wind"]), sum(FEEDER["pv"]), sum(FEEDER["load_peak"])
CAP, P_TOT, E_TOT = 2 * FEEDER["tr_cap"], sum(FEEDER["bess_p"]), sum(FEEDER["bess_e"])
BETAS = [0.9, 0.95, 0.98]
ALPHAS = [0.1, 0.05, 0.02, 0.01, 0.005, 0.002]


def hindsight_need(d):
    T = len(d)
    idx = np.clip(np.arange(T)[:, None] + np.arange(1, H + 1)[None], 0, T - 1)
    net = LPK * d.load.values[idx] - WCAP * d.wind.values[idx] - PCAP * d.solar.values[idx]
    deficit = np.maximum(net - CAP, 0)
    head = np.minimum(np.maximum(CAP - net, 0), P_TOT)
    need = np.zeros(T)
    for h in range(H - 1, -1, -1):
        need = np.maximum(0, need + deficit[:, h] / ETA - ETA * head[:, h])
    return need


def features(d):
    T = len(d)
    f = {}
    for c in ("wind", "solar", "load"):
        s = d[c]
        f[c] = s.values
        for L in (1, 3, 6, 12, 24):
            f[f"{c}_l{L}"] = s.shift(L).bfill().values
        f[f"{c}_m24"] = s.rolling(24, min_periods=1).mean().values
    f["net_now"] = LPK * d.load.values - WCAP * d.wind.values - PCAP * d.solar.values
    idx = np.clip(np.arange(T)[:, None] + np.arange(1, H + 1)[None] - 168, 0, T - 1)
    lw = d.load.values[idx]                       # last-week load for the coming 24 h (known)
    f["lw_mean"], f["lw_max"] = lw.mean(1), lw.max(1)
    f["lw_net_max"] = (LPK * lw).max(1) - CAP
    f["price"] = d.price.values
    hr, doy = d.hour.values, d.doy.values
    f["h_s"], f["h_c"] = np.sin(2 * np.pi * hr / 24), np.cos(2 * np.pi * hr / 24)
    f["d_s"], f["d_c"] = np.sin(2 * np.pi * doy / 366), np.cos(2 * np.pi * doy / 366)
    f["wkend"] = (d.dow.values >= 5).astype(float)
    return pd.DataFrame(f, index=d.index)


def main(cmd):
    d, arr = load_data()
    if cmd == "fit":
        t0 = time.time()
        y = hindsight_need(d)
        X = features(d)
        tr = (d.year <= 2017).values
        cal = (d.year == 2018).values
        out = {"y": y}
        for b in BETAS:
            m = HistGradientBoostingRegressor(loss="quantile", quantile=b, max_iter=400, learning_rate=0.05,
                                              max_leaf_nodes=31, min_samples_leaf=40, random_state=0)
            m.fit(X[tr], y[tr])
            q = np.maximum(m.predict(X), 0)
            res = y[cal] - q[cal]
            out[b] = {"q": q, "res_cal": res}
            cov_tr = np.mean(y[tr] <= q[tr]); cov_cal = np.mean(y[cal] <= q[cal])
            print(f"beta={b}: coverage train {cov_tr:.3f} cal(2018) {cov_cal:.3f}  mean q {q.mean():.2f}", flush=True)
        # reference: hindsight target statistics
        print("share of hours with E*>0:", np.mean(y > 0).round(3), "mean E*:", y.mean().round(3), round(time.time() - t0))
        pickle.dump(out, open("results/conformal_fit.pkl", "wb"))
        return
    F = pickle.load(open("results/conformal_fit.pkl", "rb"))

    def ereq(b, a):
        res = F[b]["res_cal"]
        n = len(res)
        delta = np.quantile(res, min(1.0, (1 - a) * (1 + 1 / n)))
        return np.maximum(F[b]["q"] + delta, 0)

    if cmd == "tune":
        s, n = year_slice(d, 2018)
        av = sample_availability(32, n, np.random.default_rng(1234), 1.0)
        rows = []
        for b in BETAS:
            for a in ALPHAS:
                r = run_policy(RiskPolicy(ereq(b, a), "conf"), arr, None, s, n, 32, np.random.default_rng(0),
                               use_z=False, avail=av)
                rows.append(dict(beta=b, alpha=a, **{m: float(np.mean(r[m])) for m in ["LOLE", "EENS", "FCR", "TC"]}))
                print(rows[-1], flush=True)
        pd.DataFrame(rows).to_csv("results/conformal_tuning_2018.csv", index=False)
        return
    if cmd == "evaluate":
        tune = pd.read_csv("results/conformal_tuning_2018.csv")
        best = tune.sort_values("TC").iloc[0]
        e = ereq(best.beta, best.alpha)
        y = F["y"]
        out = {"beta": best.beta, "alpha": best.alpha}
        for per, (yr, K, seed) in {"test2019": (2019, 300, 2019), "stress2020": (2020, 200, 2020)}.items():
            s, n = year_slice(d, yr)
            sl = slice(s, s + n)
            print(per, "empirical coverage P(E*<=E_req):", np.mean(y[sl] <= e[sl]).round(4), "target", 1 - best.alpha)
            mask = drought_days_mask(d, s, n)
            av = sample_availability(K, n, np.random.default_rng(seed), 1.0)
            r = run_policy(RiskPolicy(e, "conf"), arr, None, s, n, K, np.random.default_rng(0), use_z=False, avail=av)
            r["EENS_drought"] = r["ens_t"][mask].sum() * 8760.0 / n
            out[per] = r
            print(per, "beta", best.beta, "alpha", best.alpha,
                  {m: round(float(np.mean(r[m])), 2) for m in ["LOLP", "LOLE", "EENS", "EENS_drought", "FCR", "TC"]},
                  flush=True)
        pickle.dump(out, open("results/smcs_conformal.pkl", "wb"))


if __name__ == "__main__":
    main(sys.argv[1])
