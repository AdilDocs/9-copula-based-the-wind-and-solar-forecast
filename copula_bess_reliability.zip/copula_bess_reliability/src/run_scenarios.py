"""Stage 1/3: dependence model -> synthetic chronological scenarios -> SMCS adequacy (rule-based operation).

For every copula family the analog-day generator is fitted on 2015-2017 and K synthetic renewable years are
generated on the 2019 calendar (2019 load). Adequacy indices are computed with component failures switched
off, so the only difference between the models is the wind-solar dependence. Reference: historical traces
2015-2019 replayed with the same load year.
Also reports the frequency of joint droughts (days with both daily-mean wind and solar CF below the
within-month 10% quantile) per model vs history.
"""
import sys, time
import numpy as np
import pandas as pd
from stage1 import AnalogDayGenerator, KINDS, NAMES
from common import load_data, year_slice
from env import FCRRule, MyopicPolicy, FeederEnv, sample_availability
from common import run_policy

K = int(sys.argv[1]) if len(sys.argv) > 1 else 100
d, arr = load_data()
tr = d[d.year <= 2017]
s19, n19 = year_slice(d, 2019)
loc = d.index.tz_convert("Europe/Berlin")
days19 = pd.DatetimeIndex(sorted(set(loc[s19:s19 + n19].normalize())))


def joint_drought_days(W, S, month):
    dw = W.reshape(-1, 24).mean(1)
    ds = S.reshape(-1, 24).mean(1)
    df = pd.DataFrame({"w": dw, "s": ds, "m": month})
    return df


# thresholds from training history (within-month 10% quantiles of daily means)
loc_tr = tr.index.tz_convert("Europe/Berlin").normalize()
dtr = tr.groupby(loc_tr)[["wind", "solar"]].mean()
dtr["m"] = dtr.index.month
thr = dtr.groupby("m").quantile(0.1)


def drought_freq(dw, ds, m):
    return float(np.mean((dw < thr.wind.values[m - 1]) & (ds < thr.solar.values[m - 1])))


def make_series(W, S):
    """Map synthetic local-day series onto the hourly UTC index of 2019 (DST days trimmed/padded)."""
    out_w = np.empty(n19)
    out_s = np.empty(n19)
    loc19 = loc[s19:s19 + n19]
    day_idx = np.searchsorted(days19, loc19.normalize())
    hr = loc19.hour
    out_w[:] = W.reshape(len(days19), 24)[day_idx, hr]
    out_s[:] = S.reshape(len(days19), 24)[day_idx, hr]
    return out_w, out_s


rows = []
pols = [MyopicPolicy(), FCRRule()]
nofail = sample_availability(1, n19, np.random.default_rng(0), 0.0)
# history reference: each historical renewable year (2015-2019) with 2019 load and calendar
hist = []
for y in range(2015, 2020):
    sy, ny = year_slice(d, y)
    a2 = {k: v.copy() for k, v in arr.items()}
    n = min(ny, n19)
    a2["wind"][s19:s19 + n] = arr["wind"][sy:sy + n]
    a2["solar"][s19:s19 + n] = arr["solar"][sy:sy + n]
    r = {}
    for p in pols:
        o = run_policy(p, a2, None, s19, n19, 1, np.random.default_rng(0), use_z=False, avail=nofail)
        r[p.name] = (float(o["EENS"][0]), float(o["LOLE"][0]))
    lyd = d.index[sy:sy + ny].tz_convert("Europe/Berlin").normalize()
    dd = d.iloc[sy:sy + ny].groupby(lyd)[["wind", "solar"]].mean()
    hist.append(dict(year=y, jd=drought_freq(dd.wind.values, dd.solar.values, dd.index.month.values), **{
        f"EENS_{k}": v[0] for k, v in r.items()}, **{f"LOLE_{k}": v[1] for k, v in r.items()}))
hist = pd.DataFrame(hist)
print(hist)
rows.append(dict(model="Historical traces (2015-2019)", joint_drought_freq=hist.jd.mean(),
                 **{c: hist[c].mean() for c in hist.columns if c.startswith(("EENS", "LOLE"))}))
for k in KINDS:
    t0 = time.time()
    g = AnalogDayGenerator(tr, k, L=7)
    W, S = g.generate(days19, K, np.random.default_rng(42))
    jd = [drought_freq(W[i].reshape(-1, 24).mean(1), S[i].reshape(-1, 24).mean(1), days19.month.values) for i in range(K)]
    # stack the K synthetic years into one long series; trajectory i starts at i*n19
    big = {kk: np.tile(v[s19:s19 + n19], K) for kk, v in arr.items()}
    ws = [make_series(W[i], S[i]) for i in range(K)]
    big["wind"] = np.concatenate([w for w, _ in ws])
    big["solar"] = np.concatenate([s_ for _, s_ in ws])
    big = {kk: np.r_[v, v[-1:]] for kk, v in big.items()}
    nf = np.repeat(nofail, K, 0)
    res = {}
    for p in pols:
        if hasattr(p, "lo"):
            p = type(p)(big["price"])
        o = run_policy(p, big, None, 0, n19, K, np.random.default_rng(0), use_z=False, avail=nf,
                       starts=np.arange(K) * n19)
        res[p.name] = np.column_stack([o["EENS"], o["LOLE"]])
    row = dict(model=NAMES[k], joint_drought_freq=float(np.mean(jd)), daily_copula=str(g.cop.describe()))
    for p in pols:
        arr_ = res[p.name]
        row[f"EENS_{p.name}"] = arr_[:, 0].mean()
        row[f"EENS_se_{p.name}"] = arr_[:, 0].std() / np.sqrt(K)
        row[f"LOLE_{p.name}"] = arr_[:, 1].mean()
    rows.append(row)
    print(row, round(time.time() - t0, 1), flush=True)
pd.DataFrame(rows).to_csv("results/table_scenario_models.csv", index=False)
